// =============================================================================
// LAB 11 (Go) — Run concurrent Go tasks with goroutines
// Week 6 | Қысқаша: goroutine, WaitGroup, Mutex, параллель орындау.
// -----------------------------------------------------------------------------
// KEY IDEAS
//   - `go f()` starts f as a GOROUTINE: a very light "thread" managed by Go.
//   - main does not wait for goroutines. If main ends, all goroutines die.
//     sync.WaitGroup lets main wait: Add(1) before, Done() inside, Wait() after.
//   - Two goroutines writing the same variable at once = RACE CONDITION.
//     sync.Mutex makes sure only one goroutine is inside Lock()...Unlock().
//   - Since Go 1.22 each loop iteration has its OWN copy of the loop variables,
//     so a closure may safely use `i` and `n` (go.mod must say go 1.22+).
//
// TRY: `go run -race .` finds races (on Windows it needs gcc / CGO).
//
// HOW TO RUN:  go run .
//
// EXPECTED OUTPUT
//   squares: [1 4 9 16 25 36]
//   counter: 1000
//   parallel faster than sequential: true
// =============================================================================

package main

import (
	"fmt"
	"sync"
	"time"
)

// square pretends to do slow work (10 ms) and returns n*n.
// KZ: square баяу жұмысты (10 мс) бейнелеп, n*n қайтарады.
func square(n int) int {
	time.Sleep(10 * time.Millisecond)
	return n * n
}

func main() {
	// ---- 1. WaitGroup + results written by index ----------------------------
	// KZ: ---- 1. WaitGroup + нәтижелер индекс бойынша жазылады ----
	nums := []int{1, 2, 3, 4, 5, 6}
	results := make([]int, len(nums)) // one slot per number
	// KZ: әр санға бір ұяшық

	var wg sync.WaitGroup
	for i, n := range nums {
		wg.Add(1) // "one more task to wait for" — call BEFORE starting it
		// KZ: «күтетін тағы бір тапсырма» — оны іске қосудан БҰРЫН шақырыңыз
		go func() {
			defer wg.Done() // "this task is finished" (runs at the end)
			// KZ: «бұл тапсырма аяқталды» (соңында орындалады)
			results[i] = square(n) // each goroutine writes its OWN slot: no race
			// KZ: әр goroutine ӨЗ ұяшығына жазады: race жоқ
		}()
	}
	wg.Wait() // block until the counter is back to zero
	// KZ: санауыш қайта нөлге түскенше күтеді
	fmt.Println("squares:", results)

	// ---- 2. Shared counter protected by a Mutex -----------------------------
	// KZ: ---- 2. Mutex қорғайтын ортақ санауыш ----
	var mu sync.Mutex
	counter := 0
	var wg2 sync.WaitGroup
	for i := 0; i < 1000; i++ {
		wg2.Add(1)
		go func() {
			defer wg2.Done()
			mu.Lock() // enter the critical section (only one goroutine at a time)
			// KZ: критикалық бөлімге кіру (бір уақытта тек бір goroutine)
			counter++ // the shared data is changed safely
			// KZ: ортақ дерек қауіпсіз өзгертіледі
			mu.Unlock()
		}()
	}
	wg2.Wait()
	fmt.Println("counter:", counter) // always 1000; without the Mutex it may be less
	// KZ: әрқашан 1000; Mutex болмаса, одан аз болуы мүмкін

	// ---- 3. Sequential vs parallel time -------------------------------------
	// KZ: ---- 3. Тізбектелген және параллель уақыт ----
	start := time.Now()
	for _, n := range nums {
		square(n) // 6 tasks one after another: about 60 ms
		// KZ: 6 тапсырма бірінен соң бірі: шамамен 60 мс
	}
	seq := time.Since(start)

	start = time.Now()
	var wg3 sync.WaitGroup
	for _, n := range nums {
		wg3.Add(1)
		go func() {
			defer wg3.Done()
			square(n) // 6 tasks at the same time: about 10 ms
			// KZ: 6 тапсырма бір мезгілде: шамамен 10 мс
		}()
	}
	wg3.Wait()
	par := time.Since(start)
	fmt.Println("parallel faster than sequential:", par < seq)
}
