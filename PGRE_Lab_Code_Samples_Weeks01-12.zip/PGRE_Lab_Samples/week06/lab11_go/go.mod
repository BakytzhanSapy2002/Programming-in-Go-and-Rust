module lab11

go 1.22
