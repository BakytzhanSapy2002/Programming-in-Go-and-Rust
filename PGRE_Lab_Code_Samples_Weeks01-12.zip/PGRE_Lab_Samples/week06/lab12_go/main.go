// =============================================================================
// LAB 12 (Go) — Coordinate goroutines using channels and cancellation
// Week 6 | Қысқаша: channel, worker pool, select, context (cancel, timeout).
// -----------------------------------------------------------------------------
// KEY IDEAS
//   - A CHANNEL is a typed pipe between goroutines:  ch <- v (send),  v := <-ch.
//     Unbuffered: sender and receiver meet. Buffered make(chan T, n): n slots.
//   - close(ch) says "no more values"; `for v := range ch` stops after that.
//   - WORKER POOL: several workers read jobs from ONE channel and write results
//     to another one.
//   - select waits for the first ready channel operation.
//   - context.Context carries a CANCEL signal (cancel()) or a DEADLINE
//     (WithTimeout) to goroutines.
//
// HOW TO RUN:  go run .
//
// EXPECTED OUTPUT
//   1^2=1 2^2=4 3^2=9 4^2=16 5^2=25 6^2=36 7^2=49 8^2=64 9^2=81
//   received: 1
//   received: 2
//   received: 3
//   cancelled: context canceled
//   slowTask: context deadline exceeded
// =============================================================================

package main

import (
	"context"
	"fmt"
	"sort"
	"sync"
	"time"
)

// result is what a worker sends back.
// KZ: result — worker кері жіберетін нәтиже.
type result struct{ job, value int }

// worker takes jobs until the jobs channel is closed.
//   - `jobs <-chan int`  : receive-only channel (direction in the type!)
//   - `out chan<- result`: send-only channel
//
// KZ: worker jobs channel жабылғанға дейін тапсырмалар алады. - `jobs <-chan int`: тек қабылдайтын
//
//	channel (бағыт типтің ішінде!) - `out chan<- result`: тек жіберетін channel
func worker(jobs <-chan int, out chan<- result, wg *sync.WaitGroup) {
	defer wg.Done()
	for j := range jobs { // ends automatically when jobs is closed AND empty
		// KZ: jobs жабылғанда ЖӘНЕ бос болғанда өздігінен аяқталады
		out <- result{job: j, value: j * j}
	}
}

// producer sends 1, 2, 3, ... until the context is cancelled.
// KZ: producer context бас тартылғанға дейін 1, 2, 3, ... жібереді.
func producer(ctx context.Context, out chan<- int) {
	defer close(out) // always close the channel you own when you finish
	// KZ: аяқтағанда өзіңіз иеленген channel-ды әрқашан жабыңыз
	for i := 1; ; i++ {
		select {
		case out <- i: // a value was sent: wait a little
			// KZ: мән жіберілді: аздап күту
			time.Sleep(10 * time.Millisecond)
		case <-ctx.Done(): // cancel() was called: stop
			// KZ: cancel() шақырылды: тоқтау
			return
		}
	}
}

// slowTask takes 200 ms but gives up when the context ends earlier.
// KZ: slowTask 200 мс алады, бірақ context ертерек аяқталса, бас тартады.
func slowTask(ctx context.Context) error {
	select {
	case <-time.After(200 * time.Millisecond): // the work finished
		// KZ: жұмыс аяқталды
		return nil
	case <-ctx.Done(): // cancelled or deadline reached
		// KZ: бас тартылды немесе мерзім біті
		return ctx.Err() // explains why: "context deadline exceeded"
		// KZ: себебін түсіндіреді: "context deadline exceeded"
	}
}

func main() {
	// ---- 1. WORKER POOL: 3 workers, 9 jobs ----------------------------------
	// KZ: ---- 1. WORKER POOL: 3 worker, 9 тапсырма ----
	jobs := make(chan int, 10) // buffered: main can queue jobs without waiting
	// KZ: буферленген: main күтпей-ақ тапсырмаларды кезекке қоя алады
	out := make(chan result, 10) // buffered so workers never block on sending
	// KZ: буферленген: worker-лер жіберуде ешқашан бұғатталмайды
	var wg sync.WaitGroup
	for w := 0; w < 3; w++ {
		wg.Add(1)
		go worker(jobs, out, &wg)
	}
	for j := 1; j <= 9; j++ {
		jobs <- j
	}
	close(jobs) // IMPORTANT: otherwise the workers wait forever
	// KZ: МАҢЫЗДЫ: әйтпесе worker-лер мәңгі күтеді
	wg.Wait() // wait until all workers have finished
	// KZ: барлық worker аяқталғанша күту
	close(out) // now it is safe to close the results channel
	// KZ: енді нәтиже channel-ын жабу қауіпсіз

	var all []result
	for r := range out {
		all = append(all, r)
	}
	// Workers finish in any order, so sort the results before printing.
	// KZ: Worker-лер кез келген ретпен аяқтайды, сондықтан шығарар алдында нәтижелерді сұрыптаңыз.
	sort.Slice(all, func(a, b int) bool { return all[a].job < all[b].job })
	for _, r := range all {
		fmt.Printf("%d^2=%d ", r.job, r.value)
	}
	fmt.Println()

	// ---- 2. CANCELLATION ----------------------------------------------------
	// KZ: ---- 2. БАС ТАРТУ (CANCELLATION) ----
	ctx, cancel := context.WithCancel(context.Background())
	ch := make(chan int)
	go producer(ctx, ch)
	for v := range ch {
		fmt.Println("received:", v)
		if v == 3 {
			cancel() // tell the producer to stop
			// KZ: producer-ге тоқтауды айту
			break
		}
	}
	fmt.Println("cancelled:", ctx.Err()) // "context canceled"
	// KZ: "context canceled"

	// ---- 3. TIMEOUT ---------------------------------------------------------
	// KZ: ---- 3. ТАЙМАУТ ----
	ctx2, cancel2 := context.WithTimeout(context.Background(), 50*time.Millisecond)
	defer cancel2() // release the timer resources
	// KZ: таймер ресурстарын босату
	fmt.Println("slowTask:", slowTask(ctx2)) // the task needs 200 ms, only 50 ms allowed
	// KZ: тапсырмаға 200 мс керек, тек 50 мс рұқсат етілген
}
