// =============================================================================
// LAB 3 (Go) — Apply Go identifier and naming rules
// Week 2 | Қысқаша: идентификатор ережелері, экспорт (бас әріп), атау стилі.
// -----------------------------------------------------------------------------
// RULES SHOWN IN THIS FILE
//  1. An identifier starts with a letter or `_`, then letters, digits or `_`.
//  2. Go is case-sensitive: `total` and `Total` are different names.
//  3. A name that starts with a CAPITAL letter is EXPORTED (visible to other
//     packages). A name that starts with a small letter is private to the
//     package.
//  4. Style: camelCase / MixedCaps, never snake_case. `gofmt` formats the code.
//  5. `_` (blank identifier) means "I do not need this value".
//
// TRY: run `gofmt -l .` (lists badly formatted files) and `go vet ./...`.
//
// EXPECTED OUTPUT
//   Aigerim passed: true | group: IS-23 | max: 30
//   жас = 20
//   rules ok
// =============================================================================

package main

import "fmt"

// MaxStudents starts with a capital letter -> EXPORTED. Another package that
// imports this one could write lab03.MaxStudents.
// `const` creates a value that can never change.
// KZ: MaxStudents бас әріппен басталады -> ЭКСПОРТТАЛАДЫ. Осы пакетті импорттайтын басқа пакет
//
//	lab03.MaxStudents деп жаза алады. `const` ешқашан өзгермейтін мән жасайды.
const MaxStudents = 30

// defaultGroup starts with a small letter -> visible only inside this package.
// KZ: defaultGroup кіші әріппен басталады -> тек осы пакеттің ішінде көрінеді.
const defaultGroup = "IS-23"

// A `type ... struct` groups related values (fields). The type name `student`
// is private (small letter). The fields are private as well.
// KZ: `type ... struct` өзара байланысты мәндерді (өрістерді) топтайды. `student` тип атауы жеке
//
//	(кіші әріп). Өрістер де жеке.
type student struct {
	name  string
	grade int
}

// isPassed is a METHOD: a function attached to the type `student`.
// `(s student)` is the receiver: inside the method `s` is the student.
// It returns true when the grade is at least 50.
// KZ: isPassed — ӘДІС: `student` типіне байланған функция. `(s student)` — қабылдаушы (receiver):
//
//	әдіс ішінде `s` — студенттің өзі. Баға кемінде 50 болса, true қайтарады.
func (s student) isPassed() bool {
	return s.grade >= 50
}

func main() {
	// camelCase: first word small, next words start with a capital letter.
	// KZ: camelCase: бірінші сөз кіші әріппен, келесі сөздер бас әріппен басталады.
	studentName := "Aigerim"

	// A full declaration with an explicit type. Use it when the type is not
	// obvious or when you want a variable without an initial value.
	// KZ: Типі анық көрсетілген толық жариялау. Тип айқын болмағанда немесе бастапқы мәнсіз айнымалы
	//     керек болғанда қолданыңыз.
	var totalScore int = 87

	// A struct literal with field names (clear and safe against reordering).
	// KZ: Өріс аттары көрсетілген struct литералы (түсінікті және өрістер ретінің өзгеруінен
	//     қауіпсіз).
	s := student{name: studentName, grade: totalScore}

	// Println prints values separated by spaces.
	// KZ: Println мәндерді бос орынмен бөліп шығарады.
	fmt.Println(s.name, "passed:", s.isPassed(), "| group:", defaultGroup, "| max:", MaxStudents)

	// Go accepts Unicode letters in identifiers, so this is legal Go.
	// In real projects use English names so that everybody can type them.
	// KZ: Go идентификаторларда Юникод әріптерін қабылдайды, сондықтан бұл заңды Go. Нақты жобаларда
	//     барлығы теріп жаза алуы үшін ағылшын атауларын қолданыңыз.
	жас := 20
	fmt.Println("жас =", жас)

	// Println returns TWO values (bytes written, an error). The blank
	// identifier `_` lets us ignore a value we do not need. Here we keep the
	// first value in `n` and then also mark it as used with `_ = n`
	// (Go refuses to compile unused variables).
	// KZ: Println ЕКІ мән қайтарады (жазылған байттар саны, қате). Бос идентификатор `_` бізге керек
	//     емес мәнді елемеуге мүмкіндік береді. Мұнда бірінші мәнді `n`-де сақтап, `_ = n` арқылы
	//     қолданылған деп белгілейміз (Go қолданылмаған айнымалыны компиляцияламайды).
	n, _ := fmt.Println("rules ok")
	_ = n
}
