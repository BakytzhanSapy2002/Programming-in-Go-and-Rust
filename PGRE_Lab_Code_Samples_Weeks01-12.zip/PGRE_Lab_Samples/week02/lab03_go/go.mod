module lab03_go

go 1.22
