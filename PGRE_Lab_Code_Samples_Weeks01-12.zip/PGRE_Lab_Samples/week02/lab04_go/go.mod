module lab04_go

go 1.22
