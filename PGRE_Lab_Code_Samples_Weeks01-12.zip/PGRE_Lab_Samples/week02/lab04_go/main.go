// =============================================================================
// LAB 4 (Go) — Write Go expressions, type conversions and input/output
// Week 2 | Қысқаша: өрнектер, типтерді анық түрлендіру, консольден енгізу.
// -----------------------------------------------------------------------------
// WHAT YOU LEARN
//  1. Integer division and the remainder operator `%`.
//  2. Go NEVER converts types automatically: you write float64(x), int(y).
//  3. Reading a line from the keyboard (bufio) and converting text to a number
//     (strconv), and handling a wrong input.
//
// HOW TO RUN (PowerShell)
//   go run .                      -> type a number, press Enter
//   "36.6" | go run .             -> give the input without typing
//   "abc" | go run .              -> try a wrong input (error branch)
//
// EXPECTED OUTPUT (for the input 36.6)
//   a/b = 3  a%b = 1  -a/b = -3
//   float64(a)/float64(b) = 3.5
//   A 65! 97.5
//   Enter a temperature in Celsius: 36.6°C = 97.9°F
// =============================================================================

package main

import (
	"bufio" // buffered reading from the keyboard / files
	// KZ: клавиатурадан / файлдардан буферленген оқу
	"fmt" // formatted printing
	// KZ: пішімделген шығару
	"os" // os.Stdin = the standard input stream
	// KZ: os.Stdin = стандартты енгізу ағыны
	"strconv" // conversions between text and numbers
	// KZ: мәтін мен сандар арасындағы түрлендірулер
	"strings" // helpers for text (TrimSpace)
	// KZ: мәтінмен жұмыс көмекшілері (TrimSpace)
)

func main() {
	// ---- PART 1: expressions and integer division ---------------------------
	// `a, b := 7, 2` declares two variables in one line.
	// KZ: ---- 1-БӨЛІМ: өрнектер және бүтін бөлу ---- `a, b := 7, 2` бір жолда екі айнымалы
	//     жариялайды.
	a, b := 7, 2
	// Dividing two ints gives an int: 7/2 = 3 (the fraction is dropped,
	// rounding toward zero, so -7/2 = -3). `%` gives the remainder: 7%2 = 1.
	// KZ: Екі int-ті бөлу int береді: 7/2 = 3 (бөлшек бөлігі тасталады, нөлге қарай дөңгелектеу,
	//     сондықтан -7/2 = -3). `%` қалдықты береді: 7%2 = 1.
	fmt.Println("a/b =", a/b, " a%b =", a%b, " -a/b =", -a/b)

	// To get 3.5 we convert BOTH operands to float64 first.
	// Writing float64(a)/b would not compile: float64 and int cannot be mixed.
	// KZ: 3.5 алу үшін алдымен ЕКІ операндты да float64-ке түрлендіреміз. float64(a)/b деп жазу
	//     компиляцияланбас еді: float64 мен int-ті араластыруға болмайды.
	fmt.Println("float64(a)/float64(b) =", float64(a)/float64(b))

	// ---- PART 2: explicit type conversions ----------------------------------
	// KZ: ---- 2-БӨЛІМ: типтерді анық түрлендіру ----
	x := 65
	// string(rune(x)) turns the CODE POINT 65 into the character "A".
	// strconv.Itoa(x) turns the NUMBER 65 into the text "65" (then we add "!").
	// float64(x)*1.5 multiplies as a float.
	// (Do NOT write string(x) directly: `go vet` warns about it.)
	// KZ: string(rune(x)) 65 КОД НҮКТЕСІН "A" таңбасына айналдырады. strconv.Itoa(x) 65 САНЫН "65"
	//     мәтініне айналдырады (одан кейін "!" қосамыз). float64(x)*1.5 float ретінде көбейтеді.
	//     (string(x) деп тікелей ЖАЗБАҢЫЗ: `go vet` ескертеді.)
	fmt.Println(string(rune(x)), strconv.Itoa(x)+"!", float64(x)*1.5)

	// ---- PART 3: input ------------------------------------------------------
	// A reader around the standard input.
	// KZ: ---- 3-БӨЛІМ: енгізу ---- Стандартты енгізуді айналдыра оқитын reader.
	reader := bufio.NewReader(os.Stdin)
	fmt.Print("Enter a temperature in Celsius: ")

	// ReadString reads up to and including the '\n' character. It returns the
	// text and an error; we ignore the error with `_` to keep the lab short.
	// KZ: ReadString '\n' таңбасын қоса алғанға дейін оқиды. Ол мәтін мен қатені қайтарады; зертхананы
	//     қысқа ұстау үшін қатені `_` арқылы елемейміз.
	line, _ := reader.ReadString('\n')

	// TrimSpace removes spaces and the line ending; ParseFloat converts the
	// text to float64 (64 = the bit size). A wrong text gives err != nil.
	// KZ: TrimSpace бос орындар мен жол соңын алып тастайды; ParseFloat мәтінді float64-ке
	//     түрлендіреді (64 — бит өлшемі). Қате мәтін err != nil береді.
	c, err := strconv.ParseFloat(strings.TrimSpace(line), 64)
	if err != nil {
		// ALWAYS check err. Here we report the problem and stop main.
		// KZ: err-ді ӘРҚАШАН тексеріңіз. Мұнда мәселені хабарлап, main-ді тоқтатамыз.
		fmt.Println("Error: please enter a number")
		return
	}

	// %.1f prints a float with 1 digit after the decimal point.
	// °F = °C * 9/5 + 32.
	// KZ: %.1f float мәнін үтірден кейін 1 таңбамен шығарады. °F = °C * 9/5 + 32.
	fmt.Printf("%.1f°C = %.1f°F\n", c, c*9/5+32)
}
