// =============================================================================
// LAB 14 (Go) — Implement and test a Go API endpoint
// Week 7 | Қысқаша: POST endpoint, валидация, httptest, table-driven тесттер.
// -----------------------------------------------------------------------------
// This is Lab 13 plus ONE new endpoint:  POST /students  (create a student).
// The tests are in main_test.go (read it next).
//
// HOW TO RUN
//   go run .                  start the server
//   go test -v ./...          run the tests (-v = show every test)
//   go test -cover ./...      show how much of the code the tests execute
//
// TRY (server running):
//   curl.exe -s -X POST -H "Content-Type: application/json" ^
//        -d "{\"name\":\"Bota\",\"grade\":95}" http://localhost:8080/students
//
// EXPECTED OUTPUT of `go test -v ./...`
//   === RUN   TestHealth
//   --- PASS: TestHealth (0.00s)
//   === RUN   TestGetStudent
//   === RUN   TestGetStudent/found
//   === RUN   TestGetStudent/not_found
//   === RUN   TestGetStudent/bad_id
//   --- PASS: TestGetStudent (0.00s)
//       --- PASS: TestGetStudent/found (0.00s)
//       --- PASS: TestGetStudent/not_found (0.00s)
//       --- PASS: TestGetStudent/bad_id (0.00s)
//   === RUN   TestCreateStudent
//   === RUN   TestCreateStudent/valid
//   === RUN   TestCreateStudent/empty_name
//   === RUN   TestCreateStudent/grade_too_high
//   === RUN   TestCreateStudent/invalid_json
//   --- PASS: TestCreateStudent (0.00s)
//       --- PASS: TestCreateStudent/valid (0.00s)
//       --- PASS: TestCreateStudent/empty_name (0.00s)
//       --- PASS: TestCreateStudent/grade_too_high (0.00s)
//       --- PASS: TestCreateStudent/invalid_json (0.00s)
//   === RUN   TestCreateThenList
//   --- PASS: TestCreateThenList (0.00s)
//   PASS
//   ok  	lab14	0.00s
// =============================================================================

package main

import (
	"encoding/json"
	"log"
	"net/http"
	"strconv"
	"sync"
)

type Student struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Grade int    `json:"grade"`
}

type Store struct {
	mu       sync.Mutex
	students []Student
}

func (s *Store) List() []Student {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]Student, len(s.students))
	copy(out, s.students)
	return out
}

func (s *Store) Get(id int) (Student, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, st := range s.students {
		if st.ID == id {
			return st, true
		}
	}
	return Student{}, false
}

// Add is NEW. It gives the next free id and stores the student.
// The id is computed under the lock, so two simultaneous requests can never
// receive the same id.
// KZ: Add — ЖАҢА. Ол келесі бос id береді және студентті сақтайды. id құлып астында есептеледі,
//
//	сондықтан бір мезгілдегі екі сұраныс ешқашан бірдей id алмайды.
func (s *Store) Add(name string, grade int) Student {
	s.mu.Lock()
	defer s.mu.Unlock()
	st := Student{ID: len(s.students) + 1, Name: name, Grade: grade}
	s.students = append(s.students, st)
	return st
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

func newMux(store *Store) *http.ServeMux {
	mux := http.NewServeMux()

	mux.HandleFunc("GET /health", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
	})

	mux.HandleFunc("GET /students", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, store.List())
	})

	mux.HandleFunc("GET /students/{id}", func(w http.ResponseWriter, r *http.Request) {
		id, err := strconv.Atoi(r.PathValue("id"))
		if err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "id must be a number"})
			return
		}
		st, ok := store.Get(id)
		if !ok {
			writeJSON(w, http.StatusNotFound, map[string]string{"error": "student not found"})
			return
		}
		writeJSON(w, http.StatusOK, st)
	})

	// NEW endpoint: create a student from a JSON body.
	// KZ: ЖАҢА endpoint: JSON денесінен студент жасау.
	mux.HandleFunc("POST /students", func(w http.ResponseWriter, r *http.Request) {
		var in Student
		// Decode reads the JSON text from the request body into `in`.
		// If the text is not valid JSON, Decode returns an error -> 400.
		// KZ: Decode JSON мәтінін сұраныс денесінен `in` ішіне оқиды. Мәтін жарамды JSON болмаса, Decode
		//     қате қайтарады -> 400.
		if err := json.NewDecoder(r.Body).Decode(&in); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid json"})
			return
		}
		// VALIDATION: never trust the client's data.
		// KZ: ВАЛИДАЦИЯ: клиент деректеріне ешқашан сенбеңіз.
		if in.Name == "" || in.Grade < 0 || in.Grade > 100 {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "name is required, grade must be 0..100"})
			return
		}
		// 201 Created: a new resource was made; the body shows it (with its id).
		// KZ: 201 Created: жаңа ресурс жасалды; дене оны (id-мен бірге) көрсетеді.
		writeJSON(w, http.StatusCreated, store.Add(in.Name, in.Grade))
	})

	return mux
}

func main() {
	store := &Store{students: []Student{{1, "Aigerim", 90}, {2, "Yerlan", 85}}}
	log.Println("listening on http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", newMux(store)))
}
