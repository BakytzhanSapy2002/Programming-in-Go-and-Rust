// main_test.go — automated tests for the API.
//
// RULES OF `go test`
//   - The file name ends with _test.go (it is NOT part of the normal build).
//   - A test is a function named TestXxx(t *testing.T).
//   - t.Errorf reports a failure and continues; t.Fatalf reports and stops.
//
// httptest lets us call the handlers WITHOUT starting a real server:
//
//	httptest.NewRequest   builds a fake request
//	httptest.NewRecorder  records the answer (status code, headers, body)
//
// KZ: main_test.go — API үшін автоматты тесттер. `go test` ЕРЕЖЕЛЕРІ - Файл аты _test.go-мен
//
//	аяқталады (ол қалыпты құрастыруға кірмейді). - Тест — TestXxx(t *testing.T) аталған функция.
//	- t.Errorf сәтсіздікті хабарлап, жалғастырады; t.Fatalf хабарлап, тоқтайды. httptest нақты
//	серверсіз handler-лерді шақыруға мүмкіндік береді: httptest.NewRequest жалған сұраныс
//	жасайды; httptest.NewRecorder жауапты (статус коды, тақырыптар, дене) жазып алады.
package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

// newTestServer returns a FRESH router with one student. Every test calls it,
// so the tests never influence each other.
// KZ: newTestServer бір студенті бар ЖАҢА маршрутизатор қайтарады. Әр тест оны шақырады, сондықтан
//
//	тесттер бір-біріне әсер етпейді.
func newTestServer() http.Handler {
	store := &Store{students: []Student{{1, "Aigerim", 90}}}
	return newMux(store)
}

// do is a helper: send one request to the handler and return the recorded answer.
// KZ: do — көмекші: handler-ге бір сұраныс жіберіп, жазылған жауапты қайтарады.
func do(h http.Handler, method, path, body string) *httptest.ResponseRecorder {
	req := httptest.NewRequest(method, path, strings.NewReader(body))
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req) // call the handler directly
	// KZ: handler-ді тікелей шақырамыз
	return rec
}

func TestHealth(t *testing.T) {
	rec := do(newTestServer(), http.MethodGet, "/health", "")
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d", rec.Code, http.StatusOK)
	}
	if got := strings.TrimSpace(rec.Body.String()); got != "{\"status\":\"ok\"}" {
		t.Errorf("body = %s", got)
	}
}

// TABLE-DRIVEN test: the cases are data in a slice; one loop runs them all.
// Adding a case = adding one line. t.Run gives every case its own name.
// KZ: TABLE-DRIVEN тест: жағдайлар slice ішіндегі дерек; бір цикл бәрін орындайды. Жағдай қосу =
//
//	бір жол қосу. t.Run әр жағдайға өз атын береді.
func TestGetStudent(t *testing.T) {
	tests := []struct {
		name string
		path string
		want int
	}{
		{"found", "/students/1", http.StatusOK},
		{"not found", "/students/99", http.StatusNotFound},
		{"bad id", "/students/abc", http.StatusBadRequest},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			rec := do(newTestServer(), http.MethodGet, tc.path, "")
			if rec.Code != tc.want {
				t.Errorf("status = %d, want %d", rec.Code, tc.want)
			}
		})
	}
}

// Normal and BOUNDARY/invalid inputs of the POST endpoint.
// KZ: POST endpoint-інің қалыпты және ШЕКАРАЛЫҚ/жарамсыз кірістері.
func TestCreateStudent(t *testing.T) {
	tests := []struct {
		name string
		body string
		want int
	}{
		{"valid", "{\"name\":\"Bota\",\"grade\":95}", http.StatusCreated},
		{"empty name", "{\"name\":\"\",\"grade\":50}", http.StatusBadRequest},
		{"grade too high", "{\"name\":\"Bota\",\"grade\":101}", http.StatusBadRequest},
		{"invalid json", "{name:", http.StatusBadRequest},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			rec := do(newTestServer(), http.MethodPost, "/students", tc.body)
			if rec.Code != tc.want {
				t.Errorf("status = %d, want %d", rec.Code, tc.want)
			}
		})
	}
}

// Integration-style test: create a student, then check the list has 2 items.
// KZ: Интеграциялық стиль тесті: студент жасап, тізімде 2 элемент бар екенін тексереміз.
func TestCreateThenList(t *testing.T) {
	h := newTestServer() // ONE server for both calls
	// KZ: екі шақыру үшін БІР сервер
	do(h, http.MethodPost, "/students", "{\"name\":\"Bota\",\"grade\":95}")
	rec := do(h, http.MethodGet, "/students", "")
	var list []Student
	if err := json.NewDecoder(rec.Body).Decode(&list); err != nil {
		t.Fatal(err)
	}
	if len(list) != 2 {
		t.Fatalf("len = %d, want 2", len(list))
	}
}
