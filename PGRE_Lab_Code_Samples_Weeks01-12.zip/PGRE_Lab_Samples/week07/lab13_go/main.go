// =============================================================================
// LAB 13 (Go) — Build a simple Go HTTP server
// Week 7 | Қысқаша: net/http, маршруттар, JSON жауап, path параметрі.
// -----------------------------------------------------------------------------
// KEY IDEAS
//   - http.Handler / HandlerFunc: a function(w, r) that answers ONE request.
//     w (ResponseWriter) = where you write the answer; r (*Request) = the question.
//   - http.ServeMux is the router. Since Go 1.22 a pattern may contain the HTTP
//     method and a path parameter:  "GET /students/{id}"  ->  r.PathValue("id").
//   - Every request is handled in its OWN goroutine, so shared data (Store)
//     must be protected by a Mutex.
//   - The routes are built in newMux(), separate from main(), so that tests
//     (Lab 14) can use them without opening a network port.
//
// HOW TO RUN (two terminals, PowerShell)
//   terminal 1:  go run .                       (the server waits; stop: Ctrl+C)
//   terminal 2:  curl.exe -s http://localhost:8080/health
//                curl.exe -s http://localhost:8080/students
//                curl.exe -s http://localhost:8080/students/1
//                curl.exe -s -w "`nHTTP %{http_code}`n" http://localhost:8080/students/99
//   (In PowerShell `curl` is an alias of another command: write curl.exe.)
//
// EXPECTED RESPONSES
//   $ curl.exe -s http://localhost:8080/health
//   {"status":"ok"}
//   $ curl.exe -s http://localhost:8080/students
//   [{"id":1,"name":"Aigerim","grade":90},{"id":2,"name":"Yerlan","grade":85}]
//   $ curl.exe -s http://localhost:8080/students/1
//   {"id":1,"name":"Aigerim","grade":90}
//   $ curl.exe -s -w "`nHTTP %{http_code}`n" http://localhost:8080/students/99
//   {"error":"student not found"}
//
//   HTTP 404
// =============================================================================

package main

import (
	"encoding/json"
	"log"
	"net/http"
	"strconv"
	"sync"
)

// Student is sent to the client as JSON. The `json:"..."` STRUCT TAGS choose
// the key names in the JSON text (otherwise the Go field names would be used).
// KZ: Student клиентке JSON түрінде жіберіледі. `json:"..."` STRUCT TAG-тері JSON мәтініндегі кілт
//
//	аттарын таңдайды (әйтпесе Go өріс аттары қолданылар еді).
type Student struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Grade int    `json:"grade"`
}

// Store keeps the data in memory. The Mutex protects `students` because many
// requests (goroutines) may read it at the same time.
// KZ: Store деректі жадта сақтайды. Mutex `students`-ты қорғайды, себебі көп сұраныс (goroutine)
//
//	оны бір мезгілде оқуы мүмкін.
type Store struct {
	mu       sync.Mutex
	students []Student
}

// List returns a COPY of the slice, so callers cannot change our internal data.
// KZ: List slice-тың КӨШІРМЕСІН қайтарады, сондықтан шақырушылар біздің ішкі деректі өзгерте
//
//	алмайды.
func (s *Store) List() []Student {
	s.mu.Lock()
	defer s.mu.Unlock() // always unlock, even if the function returns early
	// KZ: функция ертерек қайтса да, әрқашан босатыңыз
	out := make([]Student, len(s.students))
	copy(out, s.students)
	return out
}

// Get looks for one student; the second result tells whether it was found.
// KZ: Get бір студентті іздейді; екінші нәтиже оның табылғанын көрсетеді.
func (s *Store) Get(id int) (Student, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, st := range s.students {
		if st.ID == id {
			return st, true
		}
	}
	return Student{}, false // zero value + "not found"
	// KZ: нөлдік мән + «табылмады»
}

// writeJSON is a small helper used by every handler: it sets the header, the
// status code and writes `v` as JSON. (Order matters: headers first, then the
// status, then the body.)
// KZ: writeJSON — әр handler қолданатын шағын көмекші: ол тақырыпты, статус кодын қояды және `v`
//
//	мәнін JSON ретінде жазады. (Реті маңызды: алдымен тақырыптар, содан кейін статус, соңында
//	дене.)
func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

// newMux builds the router. It returns *http.ServeMux, which is an http.Handler.
// KZ: newMux маршрутизаторды құрады. Ол http.Handler болатын *http.ServeMux қайтарады.
func newMux(store *Store) *http.ServeMux {
	mux := http.NewServeMux()

	// Health check: tells a monitoring tool that the server is alive.
	// KZ: Денсаулық тексеруі: мониторинг құралына сервердің тірі екенін хабарлайды.
	mux.HandleFunc("GET /health", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
	})

	// List all students.
	// KZ: Барлық студенттер тізімі.
	mux.HandleFunc("GET /students", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, store.List())
	})

	// One student: {id} is a path parameter.
	// KZ: Бір студент: {id} — path параметрі.
	mux.HandleFunc("GET /students/{id}", func(w http.ResponseWriter, r *http.Request) {
		id, err := strconv.Atoi(r.PathValue("id"))
		if err != nil {
			// The CLIENT sent something wrong -> 400 Bad Request.
			// KZ: КЛИЕНТ қате деректі жіберді -> 400 Bad Request.
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "id must be a number"})
			return
		}
		st, ok := store.Get(id)
		if !ok {
			// Valid request, but there is no such student -> 404 Not Found.
			// KZ: Сұраныс дұрыс, бірақ мұндай студент жоқ -> 404 Not Found.
			writeJSON(w, http.StatusNotFound, map[string]string{"error": "student not found"})
			return
		}
		writeJSON(w, http.StatusOK, st)
	})

	return mux
}

func main() {
	store := &Store{students: []Student{{1, "Aigerim", 90}, {2, "Yerlan", 85}}}
	log.Println("listening on http://localhost:8080")
	// ListenAndServe blocks forever; it returns only with an error (for example,
	// when the port is already in use), which log.Fatal prints and then exits.
	// KZ: ListenAndServe мәңгі бұғаттайды; ол тек қатемен қайтады (мысалы, порт бос емес болса), оны
	//     log.Fatal шығарып, бағдарламадан шығады.
	log.Fatal(http.ListenAndServe(":8080", newMux(store)))
}
