// =============================================================================
// LAB 7 (Go) — Define methods on Go structures
// Week 4 | Қысқаша: struct, әдістер, value/pointer receiver, конструктор, embedding.
// -----------------------------------------------------------------------------
// KEY IDEAS
//   - Go has no classes. Behaviour is attached to a type with METHODS:
//     func (receiver Type) Name(params) results { ... }
//   - VALUE receiver  (a Account)  -> the method works on a COPY.
//   - POINTER receiver (a *Account) -> the method can CHANGE the original.
//   - A constructor is just a function named NewXxx.
//   - String() makes a type printable (the fmt.Stringer interface).
//   - Embedding: a struct can include another struct and "inherit" its methods.
//
// HOW TO RUN:  go run .
//
// EXPECTED OUTPUT
//   withdraw 2000: false | balance: 1500
//   Aigerim: 1500.00
//   original: 1500 copy: 1600
//   Yerlan: 2200.00
// =============================================================================

package main

import "fmt"

// Account models a bank account.
//   - Owner starts with a capital letter  -> exported (visible to other packages).
//   - balance starts with a small letter  -> private: it can be changed only
//     through the methods below (this is ENCAPSULATION in Go).
//
// KZ: Account банк шотын модельдейді. - Owner бас әріппен басталады -> экспортталады (басқа
//
//	пакеттерге көрінеді). - balance кіші әріппен басталады -> жеке: оны тек төмендегі әдістер
//	арқылы өзгертуге болады (бұл Go-дағы ИНКАПСУЛЯЦИЯ).
type Account struct {
	Owner   string
	balance float64
}

// NewAccount is a constructor function. It returns a POINTER (*Account) so that
// all callers share one account instead of making copies.
// KZ: NewAccount — конструктор функциясы. Ол НҰСҚАҒЫШТЫ (*Account) қайтарады, сонда барлық
//
//	шақырушылар көшірме жасамай, бір шотты бөліседі.
func NewAccount(owner string, initial float64) *Account {
	// &Account{...} creates the struct and returns its address.
	// KZ: &Account{...} struct жасап, оның мекенжайын қайтарады.
	return &Account{Owner: owner, balance: initial}
}

// Deposit uses a POINTER receiver because it changes the balance.
// It returns false when the amount is not positive.
// KZ: Deposit балансты өзгерткендіктен НҰСҚАҒЫШ қабылдаушыны қолданады. Сома оң болмаса, false
//
//	қайтарады.
func (a *Account) Deposit(amount float64) bool {
	if amount <= 0 {
		return false
	}
	a.balance += amount // Go lets us write a.balance instead of (*a).balance
	// KZ: Go (*a).balance орнына a.balance деп жазуға мүмкіндік береді
	return true
}

// Withdraw also changes the balance, so it also has a pointer receiver.
// It refuses to take more money than the account has.
// KZ: Withdraw та балансты өзгертеді, сондықтан ол да нұсқағыш қабылдаушыға ие. Ол шоттағыдан көп
//
//	ақша алудан бас тартады.
func (a *Account) Withdraw(amount float64) bool {
	if amount <= 0 || amount > a.balance {
		return false
	}
	a.balance -= amount
	return true
}

// Balance only READS the data, so a value receiver is enough.
// (Rule of thumb: if any method needs a pointer receiver, use pointer
// receivers for all methods of the type — kept simple here for teaching.)
// KZ: Balance деректі тек ОҚИДЫ, сондықтан мән қабылдаушы жеткілікті. (Қарапайым ереже: типтің бір
//
//	әдісіне нұсқағыш қабылдаушы керек болса, барлық әдістерде нұсқағышты қолданыңыз — оқуды
//	жеңілдету үшін мұнда қарапайым қалдырылды.)
func (a Account) Balance() float64 { return a.balance }

// String is called automatically by fmt.Println when you print an Account.
// KZ: String Account-ты fmt.Println-мен шығарғанда автоматты түрде шақырылады.
func (a Account) String() string {
	return fmt.Sprintf("%s: %.2f", a.Owner, a.balance)
}

// SavingsAccount EMBEDS Account: it has all fields and methods of Account
// plus its own field Rate. This is composition, not inheritance.
// KZ: SavingsAccount Account-ты ЕНГІЗЕДІ (embedding): оның Account-тың барлық өрістері мен әдістері
//
//	және өз Rate өрісі бар. Бұл мұрагерлік емес, композиция.
type SavingsAccount struct {
	Account
	Rate float64
}

// AddInterest adds interest to the balance. Because Account is embedded we can
// access the private field s.balance directly (same package).
// KZ: AddInterest балансқа пайыз қосады. Account енгізілгендіктен жеке s.balance өрісіне тікелей
//
//	қол жеткізе аламыз (бір пакет).
func (s *SavingsAccount) AddInterest() {
	s.balance += s.balance * s.Rate
}

func main() {
	acc := NewAccount("Aigerim", 1000)
	acc.Deposit(500)
	ok := acc.Withdraw(2000) // too much -> false, balance stays 1500
	// KZ: тым көп -> false, баланс 1500 болып қалады
	fmt.Println("withdraw 2000:", ok, "| balance:", acc.Balance())
	fmt.Println(acc) // uses String()
	// KZ: String() қолданылады

	// VALUE vs POINTER: *acc COPIES the struct. Changing the copy does not
	// change the original.
	// KZ: МӘН пен НҰСҚАҒЫШ: *acc struct-ты КӨШІРЕДІ. Көшірмені өзгерту түпнұсқаны өзгертпейді.
	copyAcc := *acc
	copyAcc.Deposit(100)
	fmt.Println("original:", acc.Balance(), "copy:", copyAcc.Balance())

	// Embedding: Deposit is "promoted" from Account to SavingsAccount.
	// KZ: Embedding: Deposit Account-тан SavingsAccount-қа «көтеріледі» (promoted).
	sv := &SavingsAccount{Account: *NewAccount("Yerlan", 2000), Rate: 0.05}
	sv.AddInterest() // 2000 + 5% = 2100
	// KZ: 2000 + 5% = 2100
	sv.Deposit(100) // promoted method -> 2200
	// KZ: көтерілген әдіс -> 2200
	fmt.Println(sv.Account)
}
