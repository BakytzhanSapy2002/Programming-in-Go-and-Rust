// =============================================================================
// LAB 8 (Go) — Implement an interface and package API in Go
// Week 4 | Қысқаша: интерфейс, бөлек пакет (shapes), type switch.
// -----------------------------------------------------------------------------
// PROJECT LAYOUT
//   lab08_go/
//     go.mod            module name: lab08
//     main.go           THIS file (package main) — uses the shapes package
//     shapes/shapes.go  package shapes — exported API (Shape, Rectangle, ...)
//
// An import path starts with the MODULE name from go.mod: "lab08/shapes".
// Try this: rename `Largest` to `largest` in shapes.go and run again. The
// compiler says the name is not exported — that is how Go hides details.
//
// HOW TO RUN:  go run .        (and:  go doc ./shapes)
//
// EXPECTED OUTPUT
//   rectangle 3.0x4.0  area=12.00 perimeter=14.00
//   circle r=2.0       area=12.57 perimeter=12.57
//   total area = 24.57
//   largest: circle r=2.0
//   --- go doc ./shapes ---
//   package shapes // import "lab08/shapes"
//
//   Package shapes is the PUBLIC API of the second part of Lab 8. A package comment
//   (this text) is shown by `go doc ./shapes`.
//
//   A package is a folder; every file in it starts with the same `package` name.
//   Names that start with a CAPITAL letter (Shape, Rectangle, TotalArea ...) are
//   exported, i.e. other packages can use them. Everything else stays private.
//
//   func TotalArea(list []Shape) float64
//   type Circle struct{ ... }
//   type Rectangle struct{ ... }
//   type Shape interface{ ... }
//       func Largest(list []Shape) Shape
// =============================================================================

package main

import (
	"fmt"

	"lab08/shapes" // our own package: module name + folder name
	// KZ: өз пакетіміз: модуль аты + қалта аты
)

// describe shows a TYPE SWITCH: it asks which concrete type is stored inside
// the interface value s and runs the matching branch.
// `v` has the concrete type in each case, so v.Radius, v.Width ... are available.
// KZ: describe ТИП SWITCH көрсетеді: ол s интерфейс мәнінің ішінде қандай нақты тип тұрғанын сұрап,
//
//	сәйкес тармақты орындайды. `v` әр case-те нақты типке ие, сондықтан v.Radius, v.Width ...
//	қолжетімді.
func describe(s shapes.Shape) string {
	switch v := s.(type) {
	case shapes.Circle:
		return fmt.Sprintf("circle r=%.1f", v.Radius)
	case shapes.Rectangle:
		return fmt.Sprintf("rectangle %.1fx%.1f", v.Width, v.Height)
	default:
		return "unknown"
	}
}

func main() {
	// A slice of the INTERFACE type can hold different concrete types.
	// KZ: ИНТЕРФЕЙС типті slice әртүрлі нақты типтерді сақтай алады.
	list := []shapes.Shape{
		shapes.Rectangle{Width: 3, Height: 4},
		shapes.Circle{Radius: 2},
	}

	for _, s := range list {
		// %-18s = left-aligned text in a field 18 characters wide.
		// KZ: %-18s = 18 таңба енді өрісте солға туралалған мәтін.
		fmt.Printf("%-18s area=%.2f perimeter=%.2f\n", describe(s), s.Area(), s.Perimeter())
	}
	fmt.Printf("total area = %.2f\n", shapes.TotalArea(list))
	fmt.Println("largest:", describe(shapes.Largest(list)))
}
