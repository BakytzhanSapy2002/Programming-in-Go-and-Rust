// Package shapes is the PUBLIC API of the second part of Lab 8.
// A package comment (this text) is shown by `go doc ./shapes`.
//
// A package is a folder; every file in it starts with the same `package` name.
// Names that start with a CAPITAL letter (Shape, Rectangle, TotalArea ...) are
// exported, i.e. other packages can use them. Everything else stays private.
package shapes

import "math"

// Shape is an INTERFACE: a list of methods. Any type that has BOTH methods
// below is a Shape automatically — Go has no `implements` keyword
// ("if it walks like a duck and quacks like a duck, it is a duck").
// KZ: Shape — ИНТЕРФЕЙС: әдістер тізімі. Төмендегі ЕКІ әдісі де бар кез келген тип автоматты түрде
//
//	Shape болады — Go-да `implements` кілт сөзі жоқ («үйрек сияқты жүрсе және үйрек сияқты
//	қылқылдаса, ол үйрек»).
type Shape interface {
	Area() float64
	Perimeter() float64
}

// Rectangle is a rectangle with a width and a height.
// KZ: Rectangle — ені мен биіктігі бар тікбұрыш.
type Rectangle struct{ Width, Height float64 }

// Circle is a circle with a radius.
// KZ: Circle — радиусы бар дөңгелек.
type Circle struct{ Radius float64 }

// The methods of Rectangle. Because it has Area and Perimeter, Rectangle
// satisfies Shape without saying so.
// KZ: Rectangle әдістері. Оның Area және Perimeter әдістері бар болғандықтан, Rectangle Shape-ті
//
//	айтпай-ақ қанағаттандырады.
func (r Rectangle) Area() float64      { return r.Width * r.Height }
func (r Rectangle) Perimeter() float64 { return 2 * (r.Width + r.Height) }

// The methods of Circle (math.Pi is a constant from the standard library).
// KZ: Circle әдістері (math.Pi — стандартты кітапханадағы тұрақты).
func (c Circle) Area() float64      { return math.Pi * c.Radius * c.Radius }
func (c Circle) Perimeter() float64 { return 2 * math.Pi * c.Radius }

// TotalArea adds the areas of all shapes in the list. The parameter type is the
// INTERFACE, so the function works with every present and future shape.
// KZ: TotalArea тізімдегі барлық фигуралардың аудандарын қосады. Параметр типі — ИНТЕРФЕЙС,
//
//	сондықтан функция қазіргі және болашақтағы кез келген фигурамен жұмыс істейді.
func TotalArea(list []Shape) float64 {
	total := 0.0
	for _, s := range list {
		total += s.Area() // the right Area method is chosen at run time
		// KZ: дұрыс Area әдісі орындалу уақытында таңдалады
	}
	return total
}

// Largest returns the shape with the biggest area, or nil for an empty list.
// A nil interface value means "no shape".
// KZ: Largest ауданы ең үлкен фигураны қайтарады (тізім бос болса, nil). nil интерфейс мәні «фигура
//
//	жоқ» дегенді білдіреді.
func Largest(list []Shape) Shape {
	var best Shape // zero value of an interface is nil
	// KZ: интерфейстің нөлдік мәні — nil
	for _, s := range list {
		if best == nil || s.Area() > best.Area() {
			best = s
		}
	}
	return best
}
