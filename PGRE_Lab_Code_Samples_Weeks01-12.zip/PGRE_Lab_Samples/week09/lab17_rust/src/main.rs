// =============================================================================
// LAB 17 (Rust) — Trace Rust ownership, moves and copying
// Week 9 | Қысқаша: ownership, move, clone, Copy, Drop реті.
// -----------------------------------------------------------------------------
// THE 3 OWNERSHIP RULES
//   1. Every value has exactly ONE owner (a variable).
//   2. There can be only one owner at a time.
//   3. When the owner goes out of scope, the value is DROPPED (freed).
//
// CONSEQUENCES SHOWN HERE
//   * `let b = a;` for a String MOVES the value: `a` becomes unusable.
//   * `.clone()` makes a real (deep) copy — use it consciously (it costs time).
//   * Simple types (i32, bool, char, f64 ...) implement `Copy`: they are copied,
//     not moved.
//   * Passing a value to a function MOVES it into the function.
//   * Drop runs automatically at the end of the scope — we make it visible by
//     implementing the `Drop` trait for our own type.
//
// HOW TO RUN:  cargo run
//
// EXPECTED OUTPUT
//   salem
//   salem salem
//   5 5
//   inner scope ends
//   drop inner
//   take first
//   drop first
//   after take
//   second has 6 chars
//   main ends
//   drop second
// =============================================================================

// A type whose destruction we can SEE.
// KZ: Жойылуын біз КӨРЕ алатын тип.
struct Noisy {
    name: String,
}

// `Drop` is called by the compiler exactly when the value is destroyed.
// KZ: `Drop` мән жойылатын сәтте компилятор дәл шақырады.
impl Drop for Noisy {
    fn drop(&mut self) {
        println!("drop {}", self.name);
    }
}

// Helper that builds a Noisy and returns it (ownership moves to the caller).
// KZ: Noisy жасап, қайтаратын көмекші (иелік шақырушыға көшеді).
fn give(name: &str) -> Noisy {
    Noisy { name: name.to_string() }
}

// The parameter `n` OWNS the value: it is moved in from the caller and dropped
// when this function ends (the closing brace).
// KZ: `n` параметрі мәнге ИЕЛІК етеді: ол шақырушыдан көшіріліп келеді және осы функция аяқталғанда
//     (жабылатын жақшада) жойылады.
fn take(n: Noisy) {
    println!("take {}", n.name);
} // <- `n` is dropped here
// KZ: <- `n` осы жерде жойылады

fn main() {
    // ---- 1. MOVE -------------------------------------------------------------
    // KZ: ---- 1. MOVE (КӨШІРУ) ----
    let s1 = String::from("salem"); // heap data owned by s1
    // KZ: s1 иелік ететін heap деректері
    let s2 = s1; // ownership MOVES to s2; s1 is no longer valid
    // KZ: иелік s2-ге КӨШЕДІ; s1 енді жарамсыз
    println!("{}", s2);
    // println!("{}", s1); // <- would NOT compile: error[E0382] borrow of moved value
    // KZ: println!("{}", s1); // <- КОМПИЛЯЦИЯЛАНБАС ЕДІ: error[E0382] көшірілген мәнді қарызға алу

    // ---- 2. CLONE ------------------------------------------------------------
    // KZ: ---- 2. CLONE ----
    let s3 = s2.clone(); // a second, independent copy of the text
    // KZ: мәтіннің екінші, тәуелсіз көшірмесі
    println!("{} {}", s2, s3); // both are still usable
    // KZ: екеуі де әлі қолжетімді

    // ---- 3. COPY types -------------------------------------------------------
    // KZ: ---- 3. COPY типтері ----
    let a = 5;
    let b = a; // i32 is Copy: `a` stays valid
    // KZ: i32 — Copy: `a` жарамды болып қалады
    println!("{} {}", a, b);

    // ---- 4. DROP order and scopes -------------------------------------------
    // KZ: ---- 4. DROP реті және scope-тар ----
    let first = give("first");
    {
        let _inner = give("inner"); // lives only inside this block
        // KZ: тек осы блок ішінде өмір сүреді
        println!("inner scope ends");
    } // <- "drop inner" is printed here
    // KZ: <- "drop inner" осы жерде шығады
    let second = give("second");
    take(first); // `first` is MOVED into take(); dropped when take() ends
    // KZ: `first` take()-ке КӨШІРІЛЕДІ; take() аяқталғанда жойылады
    println!("after take");
    println!("second has {} chars", second.name.len());
    println!("main ends");
} // <- variables are dropped in REVERSE order of creation: "drop second"
// KZ: <- айнымалылар жасалуына КЕРІ ретпен жойылады: "drop second"
