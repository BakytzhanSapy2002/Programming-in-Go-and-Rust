// =============================================================================
// LAB 18 (Rust) — Refactor code to manage allocations and ownership  (AFTER)
// Week 9 | Қысқаша: сілтемелер (&str, &mut [T]) арқылы clone-сыз жақсы нұсқа.
// -----------------------------------------------------------------------------
// WHAT WAS IMPROVED (compare with src/bin/before.rs)
//   1. `&str` instead of `String` for read-only text: the function only LOOKS at
//      the text, so it BORROWS it. The caller keeps ownership; no clone.
//   2. The function returns a `&str` slice INTO the original text: no new
//      allocation at all.
//   3. `&mut [i32]` modifies the elements IN PLACE: no second Vec.
//   4. Vec::with_capacity reserves memory once instead of growing step by step.
//
// HOW TO RUN:  cargo run        (the old version:  cargo run --bin before)
//
// EXPECTED OUTPUT
//   ownership | Rust ownership makes memory safe
//   [2, 4, 6] (capacity 3)
// =============================================================================

// Parameter `text: &str` = "a view of some text" (a borrowed string slice).
// A `&String` converts to `&str` automatically, so callers can pass either.
// The return type `&str` is also a view — the compiler knows (lifetime elision)
// that it points into `text`.
// KZ: `text: &str` параметрі = «мәтіннің көрінісі» (қарызға алынған жол кесіндісі). `&String`
//     автоматты түрде `&str`-ге түрленеді, сондықтан шақырушылар екеуін де бере алады. Қайтарылатын
//     `&str` те көрініс — компилятор (lifetime elision) оның `text` ішіне меңзейтінін біледі.
fn longest_word(text: &str) -> &str {
    let mut best = ""; // an empty slice (no allocation)
    // KZ: бос кесінді (жад бөлу жоқ)
    for w in text.split_whitespace() {
        if w.len() > best.len() {
            best = w; // just remember WHERE the word is; nothing is copied
            // KZ: сөз ҚАЙДА екенін ғана есте сақтаймыз; ештеңе көшірілмейді
        }
    }
    best
}

// `&mut [i32]` = a mutable borrowed slice. It accepts a Vec, an array, or a
// part of them. `iter_mut()` gives `&mut i32`, and `*x` reaches the value.
// KZ: `&mut [i32]` = өзгермелі қарызға алынған кесінді. Ол Vec-ті, массивті немесе олардың бөлігін
//     қабылдайды. `iter_mut()` `&mut i32` береді, ал `*x` мәнге жеткізеді.
fn double_all(v: &mut [i32]) {
    for x in v.iter_mut() {
        *x *= 2;
    }
}

fn main() {
    let text = String::from("Rust ownership makes memory safe");
    let best = longest_word(&text); // `&text` borrows; `text` stays ours
    // KZ: `&text` қарызға алады; `text` біздікі болып қалады
    println!("{} | {}", best, text); // still usable — no clone needed
    // KZ: әлі қолжетімді — clone керек емес

    // with_capacity(3): one allocation that already has room for 3 numbers.
    // KZ: with_capacity(3): 3 санға орны бар бір жад бөлу.
    let mut nums = Vec::with_capacity(3);
    nums.extend([1, 2, 3]);
    double_all(&mut nums); // lend the Vec mutably for the duration of the call
    // KZ: шақыру уақытына Vec-ті өзгермелі түрде қарызға береміз
    println!("{:?} (capacity {})", nums, nums.capacity());
}
