// =============================================================================
// LAB 9 (Go) — Handle errors in a Go application
// Week 5 | Қысқаша: error қайтару, орау (%w), errors.Is / errors.As.
// -----------------------------------------------------------------------------
// KEY IDEAS
//   - In Go an error is an ordinary VALUE of the interface type `error`.
//   - A function that can fail returns the error as its LAST result; the caller
//     must check `if err != nil`.
//   - fmt.Errorf("...: %w", err) WRAPS an error and adds context, creating a
//     chain: "register Bota: parseAge("abc"): strconv.Atoi: ...".
//   - errors.Is(err, target)  — is `target` anywhere in the chain? (sentinel)
//   - errors.As(err, &x)      — is there an error of type X in the chain?
//   - panic is NOT for normal errors; use it only for bugs.
//
// HOW TO RUN:  go run .
//
// EXPECTED OUTPUT
//   user Aigerim (21) registered
//   error (empty name): name is empty
//   error (not a number): register Bota: parseAge("abc"): strconv.Atoi: parsing "abc": invalid syntax
//   error (range): register Yerlan: parseAge("200"): age=200 is out of range [0, 150] | max = 150
// =============================================================================

package main

import (
	"errors"
	"fmt"
	"strconv"
)

// SENTINEL error: one fixed, well-known error value to compare against.
// KZ: SENTINEL қате: салыстыруға арналған бір тұрақты, белгілі қате мәні.
var ErrEmptyName = errors.New("name is empty")

// RangeError is a CUSTOM error type. Any type with an `Error() string` method
// is an error. It carries extra data (field, value, allowed range).
// KZ: RangeError — ӨЗ қате типі. `Error() string` әдісі бар кез келген тип — қате. Ол қосымша
//
//	деректі (өріс, мән, рұқсат етілген диапазон) тасиды.
type RangeError struct {
	Field    string
	Value    int
	Min, Max int
}

// Error makes *RangeError satisfy the `error` interface.
// KZ: Error *RangeError типін `error` интерфейсін қанағаттандыратындай етеді.
func (e *RangeError) Error() string {
	return fmt.Sprintf("%s=%d is out of range [%d, %d]", e.Field, e.Value, e.Min, e.Max)
}

// validateAge returns nil (= no error) or a *RangeError.
// KZ: validateAge nil (= қате жоқ) немесе *RangeError қайтарады.
func validateAge(age int) error {
	if age < 0 || age > 150 {
		return &RangeError{Field: "age", Value: age, Min: 0, Max: 150}
	}
	return nil
}

// parseAge converts text to an age. Every failure is WRAPPED with %w so that the
// original error stays inside the new one (errors.Is/As can still find it).
// KZ: parseAge мәтінді жасқа түрлендіреді. Әр сәтсіздік %w арқылы ОРАЛАДЫ, сонда түпнұсқа қате
//
//	жаңасының ішінде қалады (errors.Is/As оны әлі таба алады).
func parseAge(s string) (int, error) {
	n, err := strconv.Atoi(s)
	if err != nil {
		return 0, fmt.Errorf("parseAge(%q): %w", s, err)
	}
	if err := validateAge(n); err != nil { // `err` here is a new, inner variable
		// KZ: осындағы `err` — жаңа, ішкі айнымалы
		return 0, fmt.Errorf("parseAge(%q): %w", s, err)
	}
	return n, nil
}

// registerUser is the top level: it adds one more layer of context.
// KZ: registerUser — жоғарғы деңгей: ол контекстің тағы бір қабатын қосады.
func registerUser(name, ageText string) error {
	if name == "" {
		return ErrEmptyName // returned as is: callers compare it with errors.Is
		// KZ: өзгертусіз қайтарылады: шақырушылар оны errors.Is арқылы салыстырады
	}
	age, err := parseAge(ageText)
	if err != nil {
		return fmt.Errorf("register %s: %w", name, err)
	}
	fmt.Printf("user %s (%d) registered\n", name, age)
	return nil
}

func main() {
	// A slice of 2-element arrays: {name, age text}.
	// KZ: 2 элементті массивтердің slice-ы: {аты, жас мәтіні}.
	inputs := [][2]string{{"Aigerim", "21"}, {"", "30"}, {"Bota", "abc"}, {"Yerlan", "200"}}

	for _, in := range inputs {
		err := registerUser(in[0], in[1])

		// Variables that errors.As will fill in when the type matches.
		// KZ: Тип сәйкес келгенде errors.As толтыратын айнымалылар.
		var rangeErr *RangeError
		var numErr *strconv.NumError

		// `switch { case ...: }` is a tidy way to test several conditions.
		// KZ: `switch { case ...: }` бірнеше шартты тексерудің ұқыпты тәсілі.
		switch {
		case err == nil:
			// success: nothing to report (the message was printed already)
			// KZ: сәтті: хабарлайтын ештеңе жоқ (хабарлама әлдеқашан шығарылды)
		case errors.Is(err, ErrEmptyName): // search the chain for the sentinel
			// KZ: тізбектен sentinel-ді іздейміз
			fmt.Println("error (empty name):", err)
		case errors.As(err, &rangeErr): // search the chain for a *RangeError
			// KZ: тізбектен *RangeError іздейміз
			fmt.Println("error (range):", err, "| max =", rangeErr.Max)
		case errors.As(err, &numErr): // search for the strconv error
			// KZ: strconv қатесін іздейміз
			fmt.Println("error (not a number):", err)
		default:
			fmt.Println("unknown error:", err)
		}
	}
}
