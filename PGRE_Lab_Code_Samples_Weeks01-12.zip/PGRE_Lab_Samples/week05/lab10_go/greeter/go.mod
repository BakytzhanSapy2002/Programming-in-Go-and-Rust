// A SECOND, independent module that lives in the sub-folder greeter/.
// KZ: greeter/ ішкі қалтасындағы ЕКІНШІ, тәуелсіз модуль.
module example.com/greeter

go 1.22
