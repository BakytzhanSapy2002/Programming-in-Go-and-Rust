// Package greeter is a tiny library used by the main module (Lab 10).
package greeter

import "fmt"

// Hello returns a greeting for the given name.
// The name starts with a capital letter, so other modules can call it.
// KZ: Hello берілген атқа сәлемдесу қайтарады. Аты бас әріппен басталады, сондықтан басқа модульдер
//
//	оны шақыра алады.
func Hello(name string) string {
	return fmt.Sprintf("Сәлем, %s!", name)
}
