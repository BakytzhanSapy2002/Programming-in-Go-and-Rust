// =============================================================================
// LAB 10 (Go) — Create a Go module and manage dependencies
// Week 5 | Қысқаша: go.mod, replace, тәуелділіктерді басқару.
// -----------------------------------------------------------------------------
// FILES
//   go.mod           main module + require + replace (read its comments!)
//   greeter/go.mod   second module
//   greeter/greeter.go   the library code
//   main.go          THIS file — imports and uses the library
//
// COMMANDS
//   go run .            run the program
//   go list -m all      list every module used by the build
//   go mod graph        show who needs whom
//   go mod tidy         add missing and remove unused requirements
//
// OPTIONAL (needs internet) — add a REAL external dependency:
//   go get github.com/google/uuid
//   then in code:  import "github.com/google/uuid"  and  uuid.NewString()
//   go.mod gets a `require` line and go.sum gets the checksums (integrity check).
//   Commit BOTH files to Git.
//
// EXPECTED OUTPUT
//   Сәлем, Go module!
//   --- go list -m all ---
//   example.com/lab10
//   example.com/greeter v0.0.0 => ./greeter
// =============================================================================

package main

import (
	"fmt"

	// The import path is the module name of the library (not the folder name).
	// KZ: Импорт жолы — кітапхананың МОДУЛЬ аты (қалта аты емес).
	"example.com/greeter"
)

func main() {
	// package name . exported function
	// KZ: пакет аты . экспортталатын функция
	fmt.Println(greeter.Hello("Go module"))
}
