// go.mod of the MAIN module.
// `module` is the name of THIS module (a domain-like path is the convention).
// KZ: НЕГІЗГІ модульдің go.mod файлы. `module` — ОСЫ модульдің аты (домен тәрізді жол — қабылданған
//     дәстүр).
module example.com/lab10

// The minimum Go language version the code needs.
// KZ: Кодқа қажет Go тілінің ең төменгі нұсқасы.
go 1.22

// `require` lists the modules this module depends on, with versions.
// v0.0.0 is a placeholder: for a local module the version is not used.
// KZ: `require` осы модуль тәуелді модульдерді нұсқаларымен тізіп көрсетеді. v0.0.0 — толтырғыш:
//     жергілікті модуль үшін нұсқа қолданылмайды.
require example.com/greeter v0.0.0

// `replace` says: "do not download example.com/greeter; use the local folder".
// This is handy while a module is still being developed.
// KZ: `replace` дегені: «example.com/greeter-ді жүктеме; жергілікті қалтаны қолдан». Модуль әлі
//     әзірленіп жатқанда ыңғайлы.
replace example.com/greeter => ./greeter
