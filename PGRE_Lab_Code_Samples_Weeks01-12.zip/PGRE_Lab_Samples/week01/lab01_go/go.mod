module lab01_go

go 1.22
