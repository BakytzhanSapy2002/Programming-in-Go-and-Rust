// =============================================================================
// LAB 1 (Go) — Install toolchains and build first programs in Go and Rust
// Week 1 | Қысқаша: Go бағдарламасының ең қарапайым құрылымы және іске қосу.
// -----------------------------------------------------------------------------
// WHAT YOU LEARN
//   1. Every Go program starts in `package main` and the function `main`.
//   2. How to import a standard-library package (`fmt`) and call its functions.
//   3. How to declare a variable with the short form `:=`.
//
// HOW TO RUN (PowerShell, inside the folder lab01_go)
//   go run .          -> compiles in a temporary folder and runs the program
//   go build          -> creates a permanent executable (lab01_go.exe on Windows)
//
// EXPECTED OUTPUT
//   Hello from Go!
//   My name is: Student
// =============================================================================

// A "package" is a folder of Go files that belong together.
// The special name `main` tells Go: "this package builds an executable program".
// (A package with any other name would be a library that other code imports.)
// KZ: «Пакет» — бірге жұмыс істейтін Go файлдарының қалтасы. `main` атауы Go-ға «бұл пакет
//
//	орындалатын бағдарлама жасайды» дейді. (Басқа атаулы пакет басқа код импорттайтын кітапхана
//	болар еді.)
package main

// `import` lists the packages that this file uses.
// "fmt" is the standard-library package for formatted input and output.
// KZ: `import` осы файл қолданатын пакеттердің тізімін көрсетеді. "fmt" — пішімделген енгізу мен
//     шығаруға арналған стандартты кітапхана пакеті.
import "fmt"

// `func main()` is the entry point: when the program starts, Go calls this
// function. Nothing runs before it (except package-level initialisation).
// KZ: `func main()` — кіру нүктесі: бағдарлама іске қосылғанда Go осы функцияны шақырады. Одан
//
//	бұрын ештеңе орындалмайды (пакет деңгейіндегі инициализацияны қоспағанда).
func main() {
	// `:=` declares a NEW variable and lets the compiler guess the type from the
	// value on the right. Here `name` becomes a `string`.
	// Replace "Student" with your own name before you run the program.
	// KZ: `:=` жаңа айнымалыны жариялайды, ал типті оң жақтағы мәннен компилятор өзі анықтайды. Мұнда
	//     `name` — `string`. Іске қоспас бұрын "Student" мәнін өз атыңызға ауыстырыңыз.
	name := "Student"

	// fmt.Println prints its arguments and adds a new line at the end.
	// KZ: fmt.Println аргументтерін шығарады және соңына жаңа жол қосады.
	fmt.Println("Hello from Go!")

	// fmt.Printf prints with a FORMAT STRING. `%s` is replaced by a string value.
	// `\n` is the escape sequence for "new line" (Printf does NOT add one itself).
	// KZ: fmt.Printf ФОРМАТ жолымен шығарады. `%s` орнына жол мәні қойылады. `\n` — «жаңа жол» таңбасы
	//     (Printf өзі жаңа жол қоспайды).
	fmt.Printf("My name is: %s\n", name)
}
