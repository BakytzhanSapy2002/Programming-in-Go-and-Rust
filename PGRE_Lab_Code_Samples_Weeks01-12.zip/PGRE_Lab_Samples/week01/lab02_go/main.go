// =============================================================================
// LAB 2 (Go) — Compare basic compilation and execution workflows
// Week 1 | Қысқаша: бір есепті Go-да жазып, run/build командаларын салыстыру.
// -----------------------------------------------------------------------------
// THE TASK: add the numbers 1 + 2 + ... + 1,000,000 (the answer is 500000500000).
// The same task is solved in Rust (lab02_rust). You compare the WORKFLOWS.
//
// COMMANDS TO COMPARE (PowerShell)
//   go run .                                -> build in a temp folder + run
//   go build -o sum.exe .                   -> build a permanent executable
//   .\sum.exe                               -> run the executable
//   go build -ldflags="-s -w" -o small.exe . -> smaller file (no debug symbols)
//   $env:GOOS="linux"; go build -o sum_linux . -> CROSS-COMPILE for Linux
//   go vet ./...                            -> look for suspicious code
//
// EXPECTED OUTPUT
//   Sum 1..1000000 = 500000500000
// =============================================================================

package main

import "fmt"

// sumTo returns 1 + 2 + ... + n.
//   - `n int`   : one parameter named n of type int (a 64-bit integer on 64-bit
//     systems, so 500000500000 fits without overflow).
//   - `int`     : after the parentheses comes the RETURN type.
//
// KZ: sumTo 1 + 2 + ... + n қосындысын қайтарады. - `n int`: int типті n атты бір параметр (64
//
//	биттік жүйеде int — 64 биттік бүтін, сондықтан 500000500000 асып кетпей сыяды). - `int`:
//	жақшалардан кейін ҚАЙТАРЫЛАТЫН тип жазылады.
func sumTo(n int) int {
	// `total` starts at 0. `:=` infers type int from the literal 0.
	// KZ: `total` 0-ден басталады. `:=` типті (int) 0 литералынан анықтайды.
	total := 0

	// Go has only ONE loop keyword: `for`. This is the classic 3-part form:
	//   init; condition; step
	// KZ: Go-да цикл кілт сөзі ЖАЛҒЫЗ: `for`. Бұл — классикалық 3 бөлімді түрі: бастапқы мән; шарт;
	//     қадам.
	for i := 1; i <= n; i++ {
		total += i // same as: total = total + i
		// KZ: мағынасы: total = total + i
	}

	// `return` hands the value back to the caller.
	// KZ: `return` мәнді шақырушыға қайтарады.
	return total
}

func main() {
	// Println accepts any number of arguments of any type and separates them
	// with a space. Here: a string followed by an int.
	// KZ: Println кез келген санды және кез келген типті аргумент қабылдайды және оларды бос орынмен
	//     бөледі. Мұнда: жол, одан кейін int.
	fmt.Println("Sum 1..1000000 =", sumTo(1000000))
}
