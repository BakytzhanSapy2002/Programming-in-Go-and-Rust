module lab02_go

go 1.22
