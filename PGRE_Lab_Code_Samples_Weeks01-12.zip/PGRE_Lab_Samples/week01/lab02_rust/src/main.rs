// =============================================================================
// LAB 2 (Rust) — Compare basic compilation and execution workflows
// Week 1 | Қысқаша: бір есеп Rust-та; debug және release режимдерін салыстыру.
// -----------------------------------------------------------------------------
// THE TASK: add 1 + 2 + ... + 1,000,000 (answer: 500000500000).
//
// COMMANDS TO COMPARE (PowerShell)
//   cargo check               -> checks the code only (fast, NO executable)
//   cargo build               -> DEBUG build:   target\debug\lab02_rust.exe
//   cargo build --release     -> RELEASE build: target\release\lab02_rust.exe
//   cargo run                 -> debug build + run
//   cargo run --release       -> optimized build + run (much faster for loops)
//
// WHY TWO MODES? Debug is quick to compile and has extra safety checks
// (e.g. it stops with an error if an integer overflows). Release is slow to
// compile but optimized for speed; overflow checks are normally removed.
//
// EXPECTED OUTPUT
//   Sum 1..1000000 = 500000500000
// =============================================================================

// Returns the sum 1 + 2 + ... + n.
//   - `n: u64`  : parameter named n of type u64 (unsigned 64-bit integer).
//     Unsigned means it can never be negative; u64 is large enough for the sum.
//   - `-> u64`  : the return type.
// KZ: 1 + 2 + ... + n қосындысын қайтарады. - `n: u64`: u64 типті n параметрі (таңбасыз 64 биттік
//     бүтін). Таңбасыз — ешқашан теріс болмайды; u64 қосынды үшін жеткілікті үлкен. - `-> u64`:
//     қайтарылатын тип.
fn sum_to(n: u64) -> u64 {
    // `let mut` makes the variable MUTABLE: we need this because we change it.
    // Without `mut`, `total += i` would be a compile error.
    // KZ: `let mut` айнымалыны ӨЗГЕРМЕЛІ етеді: бұл бізге керек, себебі оны өзгертеміз. `mut`
    //     болмаса, `total += i` компиляция қатесі болар еді.
    let mut total = 0;

    // `1..=n` is an INCLUSIVE range: 1, 2, ..., n.
    // (`1..n` would stop before n.) `for ... in` visits each value once.
    // KZ: `1..=n` — шегін қоса диапазон: 1, 2, ..., n. (`1..n` n-ге дейін тоқтайды.) `for ... in`
    //     әр мәнді бір реттен аралайды.
    for i in 1..=n {
        total += i;
    }

    // IMPORTANT: there is NO semicolon after `total`. In Rust the last
    // expression of a function (without `;`) is the return value.
    // KZ: МАҢЫЗДЫ: `total` соңында нүктелі үтір ЖОҚ. Rust-та функцияның соңғы өрнегі (`;` жоқ)
    //     қайтарылатын мән болады.
    total
}

fn main() {
    // `1_000_000` — underscores are allowed inside number literals to make
    // them readable. `{}` prints the returned value.
    // KZ: `1_000_000` — сан литералдарында оқуды жеңілдету үшін астыңғы сызықтарды қолдануға
    //     болады. `{}` қайтарылған мәнді шығарады.
    println!("Sum 1..1000000 = {}", sum_to(1_000_000));
}
