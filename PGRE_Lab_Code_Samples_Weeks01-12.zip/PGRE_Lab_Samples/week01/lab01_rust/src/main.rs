// =============================================================================
// LAB 1 (Rust) — Install toolchains and build first programs in Go and Rust
// Week 1 | Қысқаша: Rust бағдарламасының ең қарапайым құрылымы, cargo run.
// -----------------------------------------------------------------------------
// WHAT YOU LEARN
//   1. `fn main()` is the entry point of every Rust executable.
//   2. `println!` is a MACRO (the `!` shows that), not a normal function.
//   3. Variables are created with `let`.
//
// HOW TO RUN (PowerShell, inside the folder lab01_rust)
//   cargo run         -> compiles (debug mode) and runs
//   cargo build       -> only compiles; the program is in target\debug\
//
// EXPECTED OUTPUT
//   Hello from Rust!
//   My name is: Student
// =============================================================================

// `fn` declares a function. `main` is special: execution starts here.
// The parentheses are empty because main takes no parameters.
// KZ: `fn` функцияны жариялайды. `main` — ерекше функция: орындалу осыдан басталады. Жақшалар бос,
//     себебі main параметр қабылдамайды.
fn main() {
    // `let` creates a variable. By default it is IMMUTABLE (cannot change later).
    // The type (&str, a string slice) is inferred from the literal "Student".
    // KZ: `let` айнымалы жасайды. Әдепкіде ол ӨЗГЕРМЕЙТІН (кейін өзгертуге болмайды). Тип (&str —
    //     жол кесіндісі) "Student" литералынан анықталады.
    let name = "Student"; // replace with your own name
    // KZ: өз атыңызбен ауыстырыңыз

    // `println!` prints a line. Macros end with `!` because they are expanded
    // by the compiler into more code before the program is built.
    // KZ: `println!` жолды шығарады. Макростар `!` белгісімен аяқталады, себебі компилятор оларды
    //     бағдарлама құрастырылар алдында көбірек кодқа айналдырады.
    println!("Hello from Rust!");

    // `{}` is a placeholder. It is replaced by the next argument after the
    // format string. Here the placeholder receives the value of `name`.
    // KZ: `{}` — орын толтырғыш. Ол пішім жолынан кейінгі келесі аргументпен ауыстырылады. Мұнда
    //     оған `name` мәні түседі.
    println!("My name is: {}", name);
}
