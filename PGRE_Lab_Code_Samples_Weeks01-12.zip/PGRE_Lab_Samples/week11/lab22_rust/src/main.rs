// =============================================================================
// LAB 22 (Rust) — Implement a trait and handle Option and Result
// Week 11 | Қысқаша: trait, dyn/generic, Option комбинаторлары, Result, өз қатесі.
// -----------------------------------------------------------------------------
// KEY IDEAS
//   * trait  = a contract: methods a type must provide (like a Go interface, but
//     the type declares it explicitly with `impl Trait for Type`).
//   * A trait may have a DEFAULT method that types get for free.
//   * `&impl Trait` / generics `<T: Trait>` = STATIC dispatch (fast, one copy of
//     the function per type).  `Box<dyn Trait>` = DYNAMIC dispatch (one list can
//     hold different types; the method is chosen at run time).
//   * Option<T> = maybe a value;  Result<T, E> = success or error.
//   * To print an error nicely implement `fmt::Display` (and `Error`).
//
// HOW TO RUN:  cargo run
//
// EXPECTED OUTPUT
//   a dog
//   book 'Rust' (500 pages)
//   A DOG
//   age 25
//   error: 'abc' is not a number
//   error: 200 is too big
//   7
//   nobody
//   Yerlan
// =============================================================================
use std::fmt;

// The contract. `&self` = the method only reads the value.
// KZ: Келісім. `&self` = әдіс мәнді тек оқиды.
trait Describe {
    fn describe(&self) -> String; // REQUIRED: every type must write its own
    // KZ: МІНДЕТТІ: әр тип өз нұсқасын жазуы керек

    // DEFAULT method: built from the required one. Types may override it.
    // KZ: ӘДЕПКІ әдіс: міндетті әдістен құрастырылған. Типтер оны қайта анықтай алады.
    fn shout(&self) -> String {
        self.describe().to_uppercase()
    }
}

struct Dog; // a "unit struct": no fields
// KZ: «unit struct»: өрістері жоқ

struct Book {
    title: String,
    pages: u32,
}

// `impl Trait for Type` = "Dog fulfils the Describe contract".
// KZ: `impl Trait for Type` = «Dog Describe келісімін орындайды».
impl Describe for Dog {
    fn describe(&self) -> String {
        "a dog".to_string()
    }
}

impl Describe for Book {
    fn describe(&self) -> String {
        format!("book '{}' ({} pages)", self.title, self.pages)
    }
}

// DYNAMIC dispatch: a slice of boxed trait objects can hold a Dog AND a Book.
// KZ: ДИНАМИКАЛЫҚ dispatch: boxed trait object-тердің slice-ы Dog-ты ДА, Book-ты ДА сақтай алады.
fn print_all(items: &[Box<dyn Describe>]) {
    for item in items {
        println!("{}", item.describe());
    }
}

// STATIC dispatch: generic with a TRAIT BOUND — "T can be any type that
// implements Describe". The compiler generates code for each real type.
// KZ: СТАТИКАЛЫҚ dispatch: ТРЕЙТ ШЕГІ бар generic — «T Describe іске асыратын кез келген тип болуы
//     мүмкін». Компилятор әр нақты тип үшін код жасайды.
fn loudest<T: Describe>(item: &T) -> String {
    item.shout()
}

// ---- a custom error type -------------------------------------------------------
// KZ: ---- өз қате типі ----
#[derive(Debug)]
enum AgeError {
    NotANumber(String),
    TooBig(u32),
}

// Display = how the error looks for a human (`{}` in println!).
// KZ: Display = қате адамға қалай көрінеді (println!-дегі `{}`).
impl fmt::Display for AgeError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            AgeError::NotANumber(s) => write!(f, "'{}' is not a number", s),
            AgeError::TooBig(n) => write!(f, "{} is too big", n),
        }
    }
}

// Marks the type as a real error (it needs Debug + Display, which we have).
// KZ: Типті нақты қате ретінде белгілейді (ол Debug + Display талап етеді, олар бізде бар).
impl std::error::Error for AgeError {}

// Result<u32, AgeError>: Ok(age) or Err(AgeError).
// KZ: Result<u32, AgeError>: Ok(жас) немесе Err(AgeError).
fn parse_age(s: &str) -> Result<u32, AgeError> {
    // `?` returns the Err early. map_err converts ParseIntError into AgeError.
    // KZ: `?` Err-ді ерте қайтарады. map_err ParseIntError-ды AgeError-ға айналдырады.
    let n: u32 = s
        .trim()
        .parse()
        .map_err(|_| AgeError::NotANumber(s.to_string()))?;
    if n > 150 {
        Err(AgeError::TooBig(n))
    } else {
        Ok(n)
    }
}

// Option<&'static str>: `None` when the id is unknown.
// KZ: Option<&'static str>: id белгісіз болса, `None`.
fn find_user(id: u32) -> Option<&'static str> {
    match id {
        1 => Some("Aigerim"),
        2 => Some("Yerlan"),
        _ => None,
    }
}

fn main() {
    // A Vec of trait objects: `Box::new` puts each value on the heap.
    // KZ: Trait object-тердің Vec-і: `Box::new` әр мәнді heap-ке салады.
    let items: Vec<Box<dyn Describe>> = vec![
        Box::new(Dog),
        Box::new(Book { title: "Rust".to_string(), pages: 500 }),
    ];
    print_all(&items);
    println!("{}", loudest(&Dog)); // uses the DEFAULT method shout()
    // KZ: ӘДЕПКІ shout() әдісін қолданады

    // Handle Ok and Err with match.
    // KZ: Ok және Err жағдайларын match арқылы өңдеу.
    for s in ["25", "abc", "200"] {
        match parse_age(s) {
            Ok(age) => println!("age {}", age),
            Err(e) => println!("error: {}", e), // uses Display
            // KZ: Display қолданады
        }
    }

    // Option combinators: map changes the inside value, unwrap_or gives a default.
    // KZ: Option комбинаторлары: map ішкі мәнді өзгертеді, unwrap_or әдепкі мән береді.
    println!("{}", find_user(1).map(|n| n.len()).unwrap_or(0)); // length of "Aigerim"
    // KZ: "Aigerim" ұзындығы
    println!("{}", find_user(9).unwrap_or("nobody"));
    // if let: handle only the Some case.
    // KZ: if let: тек Some жағдайын өңдеу.
    if let Some(name) = find_user(2) {
        println!("{}", name);
    }
}
