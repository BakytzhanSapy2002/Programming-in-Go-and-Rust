// =============================================================================
// LAB 21 (Rust) — Define Rust structs, enums and methods
// Week 11 | Қысқаша: struct + impl, derive, деректері бар enum, match.
// -----------------------------------------------------------------------------
// KEY IDEAS
//   * struct  = several named fields in one type.
//   * impl    = the block where methods (take `self`) and associated functions
//     (no `self`, like `new`) are written.
//       &self      -> read only        &mut self -> may change the value
//       self       -> takes ownership  (none)    -> associated function: Type::f()
//   * #[derive(Debug, Clone)] asks the compiler to write standard code for us:
//     Debug  -> printing with {:?};  Clone -> .clone().
//   * enum = a value that is ONE of several variants; a variant may hold data.
//   * match must handle EVERY variant.
//
// HOW TO RUN:  cargo run
//
// EXPECTED OUTPUT
//   average (no grades): None
//   Student { name: "Aigerim", grades: [90, 85] }
//   average: 87.5
//   circle     area = 12.57
//   rectangle  area = 12.00
//   triangle   area = 6.00
// =============================================================================

#[derive(Debug, Clone)]
struct Student {
    name: String,
    grades: Vec<u32>,
}

impl Student {
    // ASSOCIATED FUNCTION (no self): works like a constructor. Call: Student::new("Dana")
    // KZ: БАЙЛАНЫСҚАН ФУНКЦИЯ (self жоқ): конструктор сияқты жұмыс істейді. Шақыру:
    //     Student::new("Dana")
    fn new(name: &str) -> Self {
        // `Self` is a short name for the type of this impl block (Student).
        // KZ: `Self` — осы impl блогының типінің (Student) қысқа аты.
        Student { name: name.to_string(), grades: Vec::new() }
    }

    // `&mut self`: the method changes the student, so the variable must be `mut`.
    // KZ: `&mut self`: әдіс студентті өзгертеді, сондықтан айнымалы `mut` болуы керек.
    fn add_grade(&mut self, grade: u32) {
        self.grades.push(grade);
    }

    // `&self`: only reads. The result is Option<f64> because an empty list has NO
    // average: None says "there is no value", so we never divide by zero.
    // KZ: `&self`: тек оқиды. Нәтиже Option<f64>, себебі бос тізімнің орташасы ЖОҚ: None «мән жоқ»
    //     дейді, сондықтан нөлге бөлмейміз.
    fn average(&self) -> Option<f64> {
        if self.grades.is_empty() {
            None
        } else {
            let sum: u32 = self.grades.iter().sum();
            Some(sum as f64 / self.grades.len() as f64)
        }
    }
}

// An enum whose variants hold DIFFERENT kinds of data.
// KZ: Нұсқалары ӘРТҮРЛІ деректі сақтайтын enum.
#[derive(Debug)]
enum Shape {
    Circle { radius: f64 },                // named field
    // KZ: аталған өріс
    Rectangle { width: f64, height: f64 }, // two named fields
    // KZ: екі аталған өріс
    Triangle(f64, f64, f64),               // three unnamed values
    // KZ: үш аталмаған мән
}

impl Shape {
    // match takes the data out of each variant (destructuring).
    // KZ: match әр нұсқадан деректі алады (destructuring).
    fn area(&self) -> f64 {
        match self {
            Shape::Circle { radius } => std::f64::consts::PI * radius * radius,
            Shape::Rectangle { width, height } => width * height,
            Shape::Triangle(a, b, c) => {
                // Heron's formula: s = half the perimeter.
                // KZ: Герон формуласы: s — периметрдің жартысы.
                let s = (a + b + c) / 2.0;
                (s * (s - a) * (s - b) * (s - c)).sqrt()
            }
        }
    }

    // `{ .. }` and `(..)` mean "ignore the data, I only need the variant".
    // KZ: `{ .. }` және `(..)` «деректі елеме, маған тек нұсқа керек» дегенді білдіреді.
    fn name(&self) -> &'static str {
        match self {
            Shape::Circle { .. } => "circle",
            Shape::Rectangle { .. } => "rectangle",
            Shape::Triangle(..) => "triangle",
        }
    }
}

fn main() {
    let mut student = Student::new("Aigerim");
    println!("average (no grades): {:?}", student.average()); // None
    // KZ: None
    student.add_grade(90);
    student.add_grade(85);
    println!("{:?}", student); // Debug output thanks to #[derive(Debug)]
    // KZ: #[derive(Debug)] арқасында Debug шығысы
    // unwrap() is fine here only because we KNOW the list is not empty.
    // KZ: unwrap() мұнда тек тізімнің бос емес екенін БІЛГЕНДІКТЕН ғана жарайды.
    println!("average: {:.1}", student.average().unwrap());

    let shapes = vec![
        Shape::Circle { radius: 2.0 },
        Shape::Rectangle { width: 3.0, height: 4.0 },
        Shape::Triangle(3.0, 4.0, 5.0),
    ];
    // `&shapes` borrows the vector, so we can still use it later.
    // KZ: `&shapes` векторды қарызға алады, сондықтан оны кейін де қолдана аламыз.
    for s in &shapes {
        // {:<10} = left-aligned in 10 characters; {:.2} = 2 decimals.
        // KZ: {:<10} = 10 таңбада солға туралау; {:.2} = үтірден кейін 2 таңба.
        println!("{:<10} area = {:.2}", s.name(), s.area());
    }
}
