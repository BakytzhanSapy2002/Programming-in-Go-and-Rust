//! # textkit
//!
//! A small library with text helpers (Lab 24).
//!
//! `//!` documents the WHOLE crate (it must be at the top of the file);
//! `///` documents the NEXT item. Run `cargo doc --open` to see the result
//! as a web page. Code blocks in doc comments are tested by `cargo test`.
// KZ: # textkit — мәтін көмекшілері бар шағын кітапхана (Lab 24). `//!` БҮКІЛ crate-ті құжаттайды
//     (файлдың басында тұруы керек); `///` КЕЛЕСІ элементті құжаттайды. `cargo doc --open` нәтижені
//     веб-бет ретінде көрсетеді. Құжат түсініктемелеріндегі код блоктары `cargo test` арқылы
//     тексеріледі.

/// Counts the words in a text (words are separated by any whitespace).
///
/// ```
/// assert_eq!(textkit::word_count("Rust is fun"), 3);
/// ```
// KZ: word_count: мәтіндегі сөздерді санайды (сөздер кез келген бос орынмен бөлінеді). Мысал:
//     assert_eq!(textkit::word_count("Rust is fun"), 3);
pub fn word_count(text: &str) -> usize {
    // split_whitespace ignores repeated spaces and empty parts.
    // KZ: split_whitespace қайталанған бос орындар мен бос бөліктерді елемейді.
    text.split_whitespace().count()
}

/// Reverses a text character by character (Unicode safe).
///
/// ```
/// assert_eq!(textkit::reverse("Қазақ"), "қазаҚ");
/// ```
// KZ: reverse: мәтінді таңба бойынша кері аударады (Юникодқа қауіпсіз). Мысал:
//     assert_eq!(textkit::reverse("Қазақ"), "қазаҚ");
pub fn reverse(text: &str) -> String {
    // chars() yields Unicode characters; rev() reverses; collect() builds a String.
    // KZ: chars() Юникод таңбаларын береді; rev() кері аударады; collect() String құрады.
    text.chars().rev().collect()
}

/// Checks whether a text reads the same backwards (letters and digits only,
/// ignoring the case).
// KZ: is_palindrome: мәтін кері оқылғанда да бірдей екенін тексереді (тек әріптер мен сандар,
//     регистрді елемей).
pub fn is_palindrome(text: &str) -> bool {
    // Keep only letters/digits and lower-case them: "A man, a plan..." -> "amanaplan..."
    // KZ: Тек әріптер/сандарды қалдырып, кіші әріпке түрлендіреміз: "A man, a plan..." ->
    //     "amanaplan...".
    let cleaned: Vec<char> = text
        .chars()
        .filter(|c| c.is_alphanumeric())
        .flat_map(|c| c.to_lowercase())
        .collect();
    // eq() compares two iterators element by element.
    // KZ: eq() екі итераторды элемент бойынша салыстырады.
    cleaned.iter().eq(cleaned.iter().rev())
}

// `#[cfg(test)]` = this module is compiled ONLY for `cargo test`.
// KZ: `#[cfg(test)]` = бұл модуль ТЕК `cargo test` үшін компиляцияланады.
#[cfg(test)]
mod tests {
    // Bring everything from the parent module (the code under test) into scope.
    // KZ: Ата-аналық модульдегі бәрін (тексерілетін кодты) көру аймағына әкеледі.
    use super::*;

    // `#[test]` marks a test function. A test FAILS if it panics.
    // KZ: `#[test]` тест функциясын белгілейді. Тест panic болса, СӘТСІЗ болады.
    #[test]
    fn counts_words() {
        assert_eq!(word_count("Rust is fun"), 3);
        assert_eq!(word_count("   "), 0); // boundary case: only spaces
        // KZ: шекаралық жағдай: тек бос орындар
    }

    #[test]
    fn reverses_unicode() {
        assert_eq!(reverse("Қазақ"), "қазаҚ");
    }

    #[test]
    fn detects_palindromes() {
        assert!(is_palindrome("A man, a plan, a canal: Panama"));
        assert!(!is_palindrome("Rust")); // assert! with `!` checks for false
        // KZ: `!` бар assert! жалғандықты тексереді
    }
}
