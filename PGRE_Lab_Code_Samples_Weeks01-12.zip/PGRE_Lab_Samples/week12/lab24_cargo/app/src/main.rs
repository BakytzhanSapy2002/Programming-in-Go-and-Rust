// =============================================================================
// LAB 24 (Rust) — Create and manage a Cargo package
// Week 12 | Қысқаша: lib + bin пакеттері, path тәуелділік, cargo командалары.
// -----------------------------------------------------------------------------
// TWO PACKAGES IN ONE FOLDER
//   lab24_cargo/textkit/   library package  (src/lib.rs)  — reusable code
//   lab24_cargo/app/       binary package   (src/main.rs) — THIS program
//
// USEFUL CARGO COMMANDS (run them inside a package folder)
//   cargo check            type-check only, fast, no executable
//   cargo build            build (debug)          cargo build --release  (optimized)
//   cargo run              build + run (only for binary packages)
//   cargo test             run unit tests + documentation tests
//   cargo doc --open       generate and open the HTML documentation
//   cargo fmt / cargo clippy   format the code / extra style and bug hints
//   cargo add rand         add a dependency from crates.io (needs internet)
//   cargo tree             show the dependency tree
//
// HOW TO RUN:  cd app   then   cargo run      (tests:  cd ../textkit ; cargo test)
//
// EXPECTED OUTPUT of `cargo run` in app/
//   words: 3
//   reversed: nuf si tsuR
//   palindrome? true
//   --- cargo test  (run inside textkit/) ---
//   running 3 tests
//   test tests::counts_words ... ok
//   test tests::detects_palindromes ... ok
//   test tests::reverses_unicode ... ok
//   test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
//   running 2 tests
//   test src/lib.rs - reverse (line 28) ... ok
//   test src/lib.rs - word_count (line 15) ... ok
//   test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
// =============================================================================

// The library is a dependency named `textkit` (see Cargo.toml), so its public
// items are imported with `use textkit::...`.
// KZ: Кітапхана `textkit` атты тәуелділік (Cargo.toml қараңыз), сондықтан оның ашық элементтері
//     `use textkit::...` арқылы импортталады.
use textkit::{is_palindrome, reverse, word_count};

fn main() {
    let text = "Rust is fun";
    println!("words: {}", word_count(text));
    println!("reversed: {}", reverse(text));
    println!("palindrome? {}", is_palindrome("Level"));
}
