// src/geometry/shapes.rs — the submodule `geometry::shapes`.
// KZ: src/geometry/shapes.rs — `geometry::shapes` ішкі модулі.

// `super` = the parent module (geometry). That is where the trait Area lives.
// KZ: `super` = ата-аналық модуль (geometry). Area trait-і сонда тұр.
use super::Area;

// The STRUCT is public (`pub struct`) but its FIELDS are private (no `pub`).
// Code outside this module cannot read or write `radius` directly.
// KZ: STRUCT ашық (`pub struct`), бірақ оның ӨРІСТЕРІ жеке (`pub` жоқ). Бұл модульден тыс код
//     `radius` өрісін тікелей оқи да, жаза да алмайды.
pub struct Circle {
    radius: f64,
}

pub struct Rect {
    width: f64,
    height: f64,
}

// Public constructors: the only way for outside code to create the values.
// KZ: Ашық конструкторлар: сыртқы кодқа мәндер жасаудың жалғыз жолы.
impl Circle {
    pub fn new(radius: f64) -> Self {
        Circle { radius }
    }
}

impl Rect {
    pub fn new(width: f64, height: f64) -> Self {
        Rect { width, height }
    }
}

// Inside the module we may use the private fields.
// KZ: Модуль ішінде жеке өрістерді қолдана аламыз.
impl Area for Circle {
    fn area(&self) -> f64 {
        std::f64::consts::PI * self.radius * self.radius
    }
}

impl Area for Rect {
    fn area(&self) -> f64 {
        self.width * self.height
    }
}
