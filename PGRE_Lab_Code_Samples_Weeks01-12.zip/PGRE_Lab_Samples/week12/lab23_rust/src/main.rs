// =============================================================================
// LAB 23 (Rust) — Organize source code into Rust modules
// Week 12 | Қысқаша: mod, pub, use, super, pub(crate), модульдер бөлек файлдарда.
// -----------------------------------------------------------------------------
// PROJECT LAYOUT (the file names matter!)
//   src/main.rs                 crate root (THIS file)
//   src/geometry.rs             module `geometry`
//   src/geometry/shapes.rs      submodule `geometry::shapes`
//
// KEY IDEAS
//   * `mod geometry;` (with a semicolon) tells the compiler: "load the module
//     from the file src/geometry.rs". `mod name { ... }` writes it inline.
//   * EVERYTHING IS PRIVATE BY DEFAULT. `pub` opens an item to the outside,
//     `pub(crate)` opens it to the whole crate only.
//   * A PATH names an item: `crate::geometry::shapes::Circle` (absolute),
//     `geometry::shapes::Circle` (relative), `super::` (parent module).
//   * `use path;` brings a name into scope so that you can write it short.
//
// HOW TO RUN:  cargo run
//
// EXPECTED OUTPUT
//   == Modules ==
//   secret = 42
//   12.57 12.00
//   total = 24.57
// =============================================================================

// Declare the module that lives in src/geometry.rs.
// KZ: src/geometry.rs файлында тұрған модульді жариялаймыз.
mod geometry;

// An INLINE module: its code is written right here between the braces.
// KZ: ІШКІ (INLINE) модуль: оның коды дәл осында жақшалар арасында жазылады.
mod utils {
    // `pub`: visible everywhere that can see the module `utils`.
    // KZ: `pub`: `utils` модулін көре алатын барлық жерде көрінеді.
    pub fn banner(title: &str) -> String {
        format!("== {} ==", title)
    }

    // `pub(crate)`: visible only inside this crate (not to external users).
    // KZ: `pub(crate)`: тек осы crate ішінде көрінеді (сыртқы пайдаланушыларға көрінбейді).
    pub(crate) fn secret() -> u32 {
        42
    }
}

// Bring names into scope. `{Circle, Rect}` imports two names at once.
// KZ: Атауларды көру аймағына әкелу. `{Circle, Rect}` екі атауды бірден импорттайды.
use geometry::shapes::{Circle, Rect};
// `Area` is a trait; its method `area` can be called only if the trait is in scope.
// KZ: `Area` — trait; оның `area` әдісін trait көру аймағында болғанда ғана шақыруға болады.
use geometry::{total_area, Area};

fn main() {
    println!("{}", utils::banner("Modules"));
    println!("secret = {}", utils::secret());

    // The fields of Circle and Rect are PRIVATE, so we cannot write
    // `Circle { radius: 2.0 }` here (error E0451). We must use the public
    // constructor `new` — this is how a module protects its invariants.
    // KZ: Circle және Rect өрістері ЖЕКЕ, сондықтан мұнда `Circle { radius: 2.0 }` деп жаза
    //     алмаймыз (E0451 қатесі). Ашық `new` конструкторын қолдануымыз керек — модуль өз
    //     инварианттарын осылай қорғайды.
    let c = Circle::new(2.0);
    let r = Rect::new(3.0, 4.0);
    println!("{:.2} {:.2}", c.area(), r.area());

    // An array of TRAIT OBJECTS (&dyn Area): different types, one interface.
    // KZ: TRAIT OBJECT-тер (&dyn Area) массиві: әртүрлі типтер, бір интерфейс.
    let shapes: [&dyn Area; 2] = [&c, &r];
    println!("total = {:.2}", total_area(&shapes));
}
