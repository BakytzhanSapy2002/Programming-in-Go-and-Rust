// src/geometry.rs — the module `geometry` (loaded by `mod geometry;` in main.rs).
// KZ: src/geometry.rs — `geometry` модулі (main.rs ішіндегі `mod geometry;` жүктейді).

// Declare the SUBMODULE. Rust looks for it in src/geometry/shapes.rs
// (the folder has the same name as this file, without .rs).
// `pub` makes the submodule reachable from main.rs as `geometry::shapes`.
// KZ: ІШКІ МОДУЛЬДІ жариялаймыз. Rust оны src/geometry/shapes.rs ішінен іздейді (қалта аты осы файл
//     атымен бірдей, .rs-сіз). `pub` ішкі модульді main.rs-тен `geometry::shapes` ретінде
//     қолжетімді етеді.
pub mod shapes;

// A public trait: the contract "can report an area".
// KZ: Ашық trait: «ауданын хабарлай алады» келісімі.
pub trait Area {
    fn area(&self) -> f64;
}

// Adds up the areas of many shapes.
// `&[&dyn Area]` = a slice of references to ANY type that implements Area.
// KZ: Көп фигураның аудандарын қосады. `&[&dyn Area]` = Area іске асыратын КЕЗ КЕЛГЕН типке
//     сілтемелердің slice-ы.
pub fn total_area(items: &[&dyn Area]) -> f64 {
    items.iter().map(|i| i.area()).sum()
}
