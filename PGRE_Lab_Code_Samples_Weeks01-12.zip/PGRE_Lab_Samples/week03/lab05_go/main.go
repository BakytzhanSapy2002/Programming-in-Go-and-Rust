// =============================================================================
// LAB 5 (Go) — Implement branching, loops and functions in Go
// Week 3 | Қысқаша: switch, for, көп мәнді функциялар, variadic, defer.
// -----------------------------------------------------------------------------
// WHAT YOU LEARN
//  1. `switch` without a condition: a clean replacement for long if/else.
//  2. `for` — the only loop keyword; `continue` and `break` control it.
//  3. Functions with several results, NAMED results and variadic parameters.
//  4. `defer` runs a call when the surrounding function ends (LIFO order).
//
// HOW TO RUN:  go run .
//
// EXPECTED OUTPUT
//   1
//   2
//   Fizz
//   4
//   Buzz
//   Fizz
//   7
//   8
//   Fizz
//   Buzz
//   11
//   Fizz
//   13
//   14
//   FizzBuzz
//   95 -> A
//   62 -> C
//   48 -> F
//   81 -> B
//   min=48 max=95 avg=71.50
//   scores count: 4
//   1 3 5 7
//   defer 2
//   defer 1
// =============================================================================

package main

import "fmt"

// classify turns a score into a letter grade.
// `switch { case condition: ... }` evaluates the cases from top to bottom and
// runs the FIRST one whose condition is true. Go does not "fall through" to the
// next case automatically, so no `break` is needed.
// KZ: classify баллды әріптік бағаға айналдырады. `switch { case шарт: ... }` case-терді жоғарыдан
//
//	төмен қарай тексеріп, шарты ШЫН БІРІНШІСІН орындайды. Go келесі case-ке автоматты түспейді,
//	сондықтан `break` керек емес.
func classify(score int) string {
	switch {
	case score >= 90:
		return "A"
	case score >= 75:
		return "B"
	case score >= 50:
		return "C"
	default: // runs when no case matched
		// KZ: ешбір case сәйкес келмегенде орындалады
		return "F"
	}
}

// stats returns THREE values: minimum, maximum and average.
//   - `nums ...int` is a VARIADIC parameter: the caller may pass any number of
//     ints; inside the function `nums` is a []int slice.
//   - `(lo, hi int, avg float64)` are NAMED results. They are ordinary
//     variables that start at their zero value; a bare `return` returns them.
//
// KZ: stats ҮШ мән қайтарады: минимум, максимум және орташа. - `nums ...int` — VARIADIC параметр:
//
//	шақырушы кез келген санды int бере алады; функция ішінде `nums` — []int slice. - `(lo, hi
//	int, avg float64)` — АТАЛҒАН нәтижелер. Олар нөлдік мәннен басталатын қарапайым айнымалылар;
//	жалаң `return` соларды қайтарады.
func stats(nums ...int) (lo, hi int, avg float64) {
	lo, hi = nums[0], nums[0] // start with the first element
	// KZ: бірінші элементтен бастаймыз
	sum := 0
	// `range` gives (index, value). `_` ignores the index.
	// KZ: `range` (индекс, мән) береді. `_` индексті елемейді.
	for _, n := range nums {
		if n < lo {
			lo = n
		}
		if n > hi {
			hi = n
		}
		sum += n
	}
	// Convert both ints to float64 before dividing, otherwise the division
	// would be an integer division.
	// KZ: Бөлер алдында екі int-ті де float64-ке түрлендіріңіз, әйтпесе бөлу бүтін бөлу болады.
	avg = float64(sum) / float64(len(nums))
	return // bare return: sends back lo, hi and avg
	// KZ: жалаң return: lo, hi және avg қайтарады
}

func main() {
	// `defer` postpones a call until main ends. Deferred calls run in
	// LAST-IN, FIRST-OUT order, so "defer 2" prints before "defer 1".
	// Typical use: closing files or unlocking mutexes.
	// KZ: `defer` шақыруды main аяқталғанша кейінге қалдырады. Кейінге қалдырылған шақырулар СОҢҒЫ
	//     КІРГЕН — БІРІНШІ ШЫҚҚАН тәртібімен орындалады, сондықтан "defer 2" "defer 1"-ден бұрын
	//     шығады. Әдеттегі қолданысы: файлдарды жабу, mutex-ті босату.
	defer fmt.Println("defer 1")
	defer fmt.Println("defer 2")

	// ---- FizzBuzz: 1..15 -----------------------------------------------------
	// KZ: ---- FizzBuzz: 1..15 ----
	for i := 1; i <= 15; i++ {
		switch {
		case i%15 == 0: // check the strongest condition FIRST
			// KZ: АЛДЫМЕН ең күшті шартты тексеріңіз
			fmt.Println("FizzBuzz")
		case i%3 == 0:
			fmt.Println("Fizz")
		case i%5 == 0:
			fmt.Println("Buzz")
		default:
			fmt.Println(i)
		}
	}

	// ---- function with a slice ---------------------------------------------
	// KZ: ---- slice-пен функция ----
	scores := []int{95, 62, 48, 81}
	for _, s := range scores {
		fmt.Printf("%d -> %s\n", s, classify(s))
	}

	// `scores...` "unpacks" the slice into separate variadic arguments.
	// KZ: `scores...` slice-ты бөлек variadic аргументтерге «ашады».
	lo, hi, avg := stats(scores...)
	fmt.Printf("min=%d max=%d avg=%.2f\n", lo, hi, avg)

	// `if` with a short statement: `n` exists only inside this if/else.
	// KZ: Қысқа операторлы `if`: `n` тек осы if/else ішінде бар.
	if n := len(scores); n > 3 {
		fmt.Println("scores count:", n)
	}

	// `continue` skips to the next iteration, `break` leaves the loop.
	// Prints the odd numbers 1, 3, 5, 7 and stops when i is greater than 7.
	// KZ: `continue` келесі итерацияға өтеді, `break` циклден шығады. Тақ сандарды 1, 3, 5, 7 шығарады
	//     және i 7-ден асқанда тоқтайды.
	for i := 0; i < 20; i++ {
		if i%2 == 0 {
			continue
		}
		if i > 7 {
			break
		}
		fmt.Print(i, " ")
	}
	fmt.Println()
}
