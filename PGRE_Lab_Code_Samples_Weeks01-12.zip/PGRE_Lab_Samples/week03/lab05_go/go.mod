module lab05_go

go 1.22
