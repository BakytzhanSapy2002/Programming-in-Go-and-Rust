// =============================================================================
// LAB 6 (Go) — Process arrays, slices, maps and strings in Go
// Week 3 | Қысқаша: массив, slice (ортақ жад), map, Юникод жолдар (rune).
// -----------------------------------------------------------------------------
// KEY IDEAS
//   - Array [3]string : FIXED size, copied by value.
//   - Slice []int     : a small "window" (pointer, length, capacity) over an
//     array. Slices can SHARE the same memory -> a change through one slice is
//     visible through the others.
//   - Map map[K]V    : a hash table; the iteration order is random.
//   - String          : read-only bytes in UTF-8. `len` counts BYTES, not
//     characters; use rune to work with characters.
//
// HOW TO RUN:  go run .
//
// EXPECTED OUTPUT
//   3 [Дс Сс Ср] [XX Сс Ср]
//   [1 99 3 4 5] [99 3 4] 3 4
//   [1 99 3 4 5 6] [-1 99 3 4 5 6]
//   go: 3
//   rust: 1
//   жылдам: 1
//   қарапайым: 1
//   қауіпсіз: 1
//   python not found, v = 0
//   bytes: 18 runes: 9
//   0 Қ
//   2 а
//   4 з
// =============================================================================

package main

import (
	"fmt"
	"sort"
	"strings"
	"unicode/utf8"
)

func main() {
	// ---- ARRAY: value semantics ---------------------------------------------
	// KZ: ---- МАССИВ: мән семантикасы ----
	days := [3]string{"Дс", "Сс", "Ср"}
	daysCopy := days // assigning an ARRAY copies all elements
	// KZ: МАССИВТІ меншіктеу барлық элементтерді көшіреді
	daysCopy[0] = "XX"
	fmt.Println(len(days), days, daysCopy) // `days` is unchanged
	// KZ: `days` өзгермейді

	// ---- SLICE: shared memory -----------------------------------------------
	// KZ: ---- SLICE: ортақ жад ----
	nums := []int{1, 2, 3, 4, 5}
	// nums[1:4] = elements with index 1, 2, 3 (the end index is EXCLUDED).
	// KZ: nums[1:4] = индексі 1, 2, 3 элементтер (соңғы индекс КІРМЕЙДІ).
	part := nums[1:4]
	part[0] = 99 // changes nums[1] too, because both use the same array!
	// KZ: nums[1]-ді де өзгертеді, себебі екеуі де бір массивті қолданады!
	// len = how many elements, cap = how many fit before a new array is needed
	// (cap counts from the start of the slice to the end of the array: 4).
	// KZ: len = элемент саны, cap = жаңа массив қажет болғанға дейін қанша сыятыны (cap slice басынан
	//     массив соңына дейін есептеледі: 4).
	fmt.Println(nums, part, len(part), cap(part))

	// append may allocate a NEW array when the capacity is exhausted.
	// KZ: сыйымдылық таусылғанда append ЖАҢА массив бөлуі мүмкін.
	nums = append(nums, 6)
	// To get an independent copy: make a slice of the same length and copy().
	// KZ: Тәуелсіз көшірме алу үшін: сондай ұзындықты slice жасап, copy() қолданыңыз.
	clone := make([]int, len(nums))
	copy(clone, nums)
	clone[0] = -1 // does not affect nums
	// KZ: nums-ке әсер етпейді
	fmt.Println(nums, clone)

	// ---- MAP: word frequency ------------------------------------------------
	// KZ: ---- MAP: сөздер жиілігі ----
	text := "Go жылдам Go қарапайым Rust қауіпсіз Go"
	freq := map[string]int{} // an empty map (NOT nil, so writing is allowed)
	// KZ: бос map (nil ЕМЕС, сондықтан жазуға болады)

	// strings.Fields splits the text on whitespace.
	// KZ: strings.Fields мәтінді бос орындар бойынша бөледі.
	for _, w := range strings.Fields(text) {
		// A missing key returns the zero value (0), so ++ works at the first use.
		// KZ: Жоқ кілт нөлдік мәнді (0) қайтарады, сондықтан ++ бірінші қолданғанда да жұмыс істейді.
		freq[strings.ToLower(w)]++
	}

	// The order of a map is random, so collect the keys and sort them to get a
	// stable output.
	// KZ: map реті кездейсоқ, сондықтан тұрақты нәтиже алу үшін кілттерді жинап, сұрыптаңыз.
	keys := make([]string, 0, len(freq))
	for k := range freq {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		fmt.Printf("%s: %d\n", k, freq[k])
	}

	// The "comma ok" form tells apart "missing key" from "value is 0".
	// KZ: "comma ok" түрі «кілт жоқ» пен «мән 0» жағдайларын ажыратады.
	if v, ok := freq["python"]; !ok {
		fmt.Println("python not found, v =", v)
	}

	// ---- STRINGS and runes --------------------------------------------------
	// KZ: ---- ЖОЛДАР және rune-дар ----
	word := "Қазақстан"
	// Each Kazakh letter takes 2 bytes in UTF-8, so bytes = 18 but runes = 9.
	// KZ: UTF-8-де әр қазақ әрпі 2 байт алады, сондықтан байттар = 18, ал rune-дар = 9.
	fmt.Println("bytes:", len(word), "runes:", utf8.RuneCountInString(word))
	// `range` over a string yields (byte position, rune), not single bytes.
	// KZ: Жол бойынша `range` (байт орны, rune) береді, жеке байттарды емес.
	for i, r := range "Қаз" {
		fmt.Println(i, string(r))
	}
}
