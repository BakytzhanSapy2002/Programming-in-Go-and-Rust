module lab06_go

go 1.22
