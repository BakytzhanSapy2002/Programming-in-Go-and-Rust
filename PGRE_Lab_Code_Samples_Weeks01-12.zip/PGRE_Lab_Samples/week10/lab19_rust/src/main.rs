// =============================================================================
// LAB 19 (Rust) — Write functions using immutable and mutable borrowing
// Week 10 | Қысқаша: &T және &mut T сілтемелері, slice параметрлері, NLL.
// -----------------------------------------------------------------------------
// BORROWING RULES (checked by the compiler, at compile time)
//   * Any number of shared references `&T` at the same time, OR
//   * exactly ONE mutable reference `&mut T` — never both together.
//   * A reference can never outlive the value it points to.
//   These rules make data races and dangling pointers impossible.
//
// NLL (non-lexical lifetimes): a reference "lives" only until its LAST USE,
// not until the end of the block. So after the last use of r1 and r2 we may
// create a `&mut`.
//
// HOW TO RUN:  cargo run
//
// EXPECTED OUTPUT
//   9 2
//   hello
//   Salem!
//   [2, 3, 4]
//   2 1
//   Salem! Salem!
//   Salem!?
// =============================================================================

// `&[String]` = a shared view of strings. It accepts a Vec<String> (via &) or an
// array. The function only reads, so the caller keeps everything.
// KZ: `&[String]` = жолдардың ортақ көрінісі. Ол Vec<String>-ті (& арқылы) немесе массивті
//     қабылдайды. Функция тек оқиды, сондықтан шақырушы бәрін өзінде сақтайды.
fn total_len(words: &[String]) -> usize {
    // iter() -> map each word to its length -> add them up.
    // KZ: iter() -> әр сөзді ұзындығына бейнелеу -> қосу.
    words.iter().map(|w| w.len()).sum()
}

// Returns a slice of the INPUT: no new String is created.
// `next()` gives Option<&str>; `unwrap_or("")` is the default for empty text.
// KZ: КІРІСТІҢ кесіндісін қайтарады: жаңа String жасалмайды. `next()` Option<&str> береді;
//     `unwrap_or("")` бос мәтін үшін әдепкі мән.
fn first_word(s: &str) -> &str {
    s.split_whitespace().next().unwrap_or("")
}

// `&mut String` lets the function CHANGE the caller's string.
// KZ: `&mut String` функцияға шақырушының жолын ӨЗГЕРТУГЕ мүмкіндік береді.
fn append_exclaim(s: &mut String) {
    s.push('!');
}

// Changes every element of a Vec in place.
// KZ: Vec-тің әр элементін орнында өзгертеді.
fn increment_all(v: &mut Vec<i32>) {
    for x in v.iter_mut() {
        *x += 1; // `*` follows the reference to the number itself
        // KZ: `*` сілтемені санның өзіне дейін ілестіреді
    }
}

// Two mutable references to DIFFERENT variables are allowed.
// KZ: ӘРТҮРЛІ айнымалыларға екі өзгермелі сілтемеге рұқсат етіледі.
fn swap_values(a: &mut i32, b: &mut i32) {
    let t = *a; // read through the reference
    // KZ: сілтеме арқылы оқу
    *a = *b;
    *b = t;
}

fn main() {
    let words = vec![String::from("alpha"), String::from("beta")];
    // `&words` lends the Vec; we can still use `words` afterwards.
    // KZ: `&words` Vec-ті қарызға береді; кейін `words`-ты әлі қолдана аламыз.
    println!("{} {}", total_len(&words), words.len());

    let sentence = String::from("hello world");
    let fw = first_word(&sentence); // &String is converted to &str automatically
    // KZ: &String автоматты түрде &str-ге түрленеді
    println!("{}", fw);

    // A mutable borrow requires the variable itself to be declared `mut`.
    // KZ: Өзгермелі қарыз алу үшін айнымалының өзі `mut` деп жариялануы керек.
    let mut greeting = String::from("Salem");
    append_exclaim(&mut greeting); // pass `&mut` explicitly: it is visible in the call
    // KZ: `&mut`-ты анық беріңіз: ол шақыруда көрінеді
    println!("{}", greeting);

    let mut v = vec![1, 2, 3];
    increment_all(&mut v);
    println!("{:?}", v);

    let (mut x, mut y) = (1, 2);
    swap_values(&mut x, &mut y);
    println!("{} {}", x, y);

    // Many shared references at once: fine, nobody can change the data.
    // KZ: Бір мезгілде көп ортақ сілтеме: дұрыс, деректі ешкім өзгерте алмайды.
    let r1 = &greeting;
    let r2 = &greeting;
    println!("{} {}", r1, r2); // last use of r1 and r2
    // KZ: r1 және r2 соңғы рет қолданылды

    // NLL: r1 and r2 are not used any more, so a mutable reference is allowed.
    // KZ: NLL: r1 және r2 енді қолданылмайды, сондықтан өзгермелі сілтемеге рұқсат етіледі.
    let r3 = &mut greeting;
    r3.push('?');
    println!("{}", r3);
}
