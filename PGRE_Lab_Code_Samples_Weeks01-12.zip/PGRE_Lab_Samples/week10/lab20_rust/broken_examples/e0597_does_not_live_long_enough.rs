// DOES NOT COMPILE ON PURPOSE.            Compile it:  rustc e0597_does_not_live_long_enough.rs
// ERROR  : error[E0597]: `x` does not live long enough
// WHY    : `x` is destroyed at the closing brace of the inner block, but `r`
//          still points to it (a DANGLING reference).
// FIX    : declare `x` in the outer scope, or copy the value:  r = x;
// KZ: КОМПИЛЯЦИЯЛАНБАЙДЫ — ҚАСТАНДЫҚПЕН. ҚАТЕ: error[E0597]: `x` жеткілікті ұзақ өмір сүрмейді.
//     СЕБЕБІ: `x` ішкі блоктың жабылатын жақшасында жойылады, ал `r` әлі де соған меңзейді (ілулі
//     сілтеме, dangling reference). ТҮЗЕТУ: `x`-ті сыртқы scope-та жариялаңыз немесе мәнді
//     көшіріңіз: r = x;
fn main() {
    let r;
    {
        let x = 5;
        r = &x;
    }
    println!("{}", r);
}
