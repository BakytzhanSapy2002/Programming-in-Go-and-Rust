// DOES NOT COMPILE ON PURPOSE.            Compile it:  rustc e0382_use_after_move.rs
// ERROR  : error[E0382]: borrow of moved value: `s`
// WHY    : `let t = s;` MOVED the String into `t`; `s` is no longer valid.
// FIX    : let t = s.clone();   (a real copy)   or just stop using `s`.
// KZ: КОМПИЛЯЦИЯЛАНБАЙДЫ — ҚАСТАНДЫҚПЕН. ҚАТЕ: error[E0382]: көшірілген `s` мәнін қарызға алу.
//     СЕБЕБІ: `let t = s;` String-ті `t`-ға КӨШІРДІ (move); `s` енді жарамсыз. ТҮЗЕТУ: let t =
//     s.clone(); (нақты көшірме) немесе `s`-ты қолданбаңыз.
fn main() {
    let s = String::from("hi");
    let t = s;
    println!("{} {}", s, t);
}
