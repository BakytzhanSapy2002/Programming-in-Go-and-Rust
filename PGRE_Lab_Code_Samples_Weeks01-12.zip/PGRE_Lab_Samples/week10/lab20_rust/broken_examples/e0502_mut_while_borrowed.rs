// DOES NOT COMPILE ON PURPOSE.            Compile it:  rustc e0502_mut_while_borrowed.rs
// ERROR  : error[E0502]: cannot borrow `v` as mutable because it is also
//          borrowed as immutable
// WHY    : `first` points INTO the vector. `push` may reallocate the vector and
//          make `first` point to freed memory, so Rust forbids it.
// FIX    : copy the value instead of borrowing it:   let first = v[0];
//          (i32 is Copy), or print `first` BEFORE calling push.
// KZ: КОМПИЛЯЦИЯЛАНБАЙДЫ — ҚАСТАНДЫҚПЕН. ҚАТЕ: error[E0502]: `v`-ны өзгермелі етіп қарызға алуға
//     болмайды, өйткені ол өзгермейтін етіп қарызға алынған. СЕБЕБІ: `first` вектордың ІШІНЕ
//     меңзейді. `push` векторды қайта бөліп, `first`-ті босатылған жадқа меңзетуі мүмкін, сондықтан
//     Rust оған тыйым салады. ТҮЗЕТУ: мәнді қарызға алудың орнына көшіріңіз: let first = v[0]; (i32
//     — Copy), немесе `first`-ті push-қа дейін шығарыңыз.
fn main() {
    let mut v = vec![1, 2, 3];
    let first = &v[0];
    v.push(4);
    println!("{}", first);
}
