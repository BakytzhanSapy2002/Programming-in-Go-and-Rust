// DOES NOT COMPILE ON PURPOSE.            Compile it:  rustc e0499_two_mut.rs
// ERROR  : error[E0499]: cannot borrow `s` as mutable more than once at a time
// WHY    : two `&mut` references to the same value are alive at once (a, b).
//          This is how Rust prevents data races.
// FIX    : use `a` completely first, then create `b`:
//              let a = &mut s; a.push('1');
//              let b = &mut s; b.push('2');
// KZ: КОМПИЛЯЦИЯЛАНБАЙДЫ — ҚАСТАНДЫҚПЕН. ҚАТЕ: error[E0499]: `s`-ты бір мезгілде бірнеше рет
//     өзгермелі етіп қарызға алуға болмайды. СЕБЕБІ: бір мәнге екі `&mut` сілтеме бір мезгілде тірі
//     (a, b). Rust осылай data race-тің алдын алады. ТҮЗЕТУ: алдымен `a`-ны толық қолданыңыз, содан
//     кейін `b` жасаңыз: let a = &mut s; a.push('1'); let b = &mut s; b.push('2');
fn main() {
    let mut s = String::from("hi");
    let a = &mut s;
    let b = &mut s;
    a.push('1');
    b.push('2');
}
