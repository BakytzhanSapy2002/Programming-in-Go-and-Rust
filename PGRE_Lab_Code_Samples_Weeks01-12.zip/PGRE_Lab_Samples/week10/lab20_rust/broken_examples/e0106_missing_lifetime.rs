// DOES NOT COMPILE ON PURPOSE.            Compile it:  rustc e0106_missing_lifetime.rs
// ERROR  : error[E0106]: missing lifetime specifier
// WHY    : the function returns a reference but gets two references as input;
//          the compiler cannot tell which one the result comes from.
// FIX    : fn longest<'a>(a: &'a str, b: &'a str) -> &'a str
// KZ: КОМПИЛЯЦИЯЛАНБАЙДЫ — ҚАСТАНДЫҚПЕН. ҚАТЕ: error[E0106]: lifetime көрсетілмеген. СЕБЕБІ:
//     функция сілтеме қайтарады, бірақ екі сілтеме қабылдайды; компилятор нәтиже қайсысынан
//     шыққанын біле алмайды. ТҮЗЕТУ: fn longest<'a>(a: &'a str, b: &'a str) -> &'a str
fn longest(a: &str, b: &str) -> &str {
    if a.len() > b.len() { a } else { b }
}

fn main() {
    println!("{}", longest("a", "bb"));
}
