// =============================================================================
// LAB 20 (Rust) — Resolve borrow-checker errors and explain lifetimes
// Week 10 | Қысқаша: lifetime параметрлері, struct ішіндегі сілтеме, 'static.
// -----------------------------------------------------------------------------
// This file is the WORKING program. The folder broken_examples/ contains four
// small programs that do NOT compile on purpose (each has the error code and the
// fix in its first comment lines). Try them like this:
//   rustc broken_examples/e0499_two_mut.rs        (read the error!)
//
// LIFETIMES IN ONE SENTENCE
//   A lifetime annotation like 'a does not change how long anything lives; it
//   TELLS THE COMPILER how the lifetimes of references are related, so it can
//   check that no reference outlives the data it points to.
//
// HOW TO RUN:  cargo run
//
// EXPECTED OUTPUT
//   lifetimes
//   Call me Ishmael
//   string literal
// =============================================================================

// `<'a>` declares a lifetime parameter. All three references share 'a: the
// returned reference is valid as long as BOTH inputs are valid (the shorter of
// the two). Without it the compiler cannot know whether the result points to
// `a` or to `b` and reports error[E0106].
// KZ: `<'a>` lifetime параметрін жариялайды. Үш сілтеме де 'a-ны бөліседі: қайтарылған сілтеме ЕКІ
//     кіріс те жарамды болғанша жарамды (екеуінің қысқасы). Онсыз компилятор нәтиже `a`-ға ма,
//     `b`-ға ма меңзейтінін біле алмай, error[E0106] хабарлайды.
fn longest<'a>(a: &'a str, b: &'a str) -> &'a str {
    if a.len() > b.len() {
        a
    } else {
        b
    }
}

// A struct that STORES a reference needs a lifetime parameter: an Excerpt
// cannot live longer than the text it points into.
// KZ: Сілтемені САҚТАЙТЫН struct-қа lifetime параметрі керек: Excerpt өзі меңзейтін мәтіннен ұзақ
//     өмір сүре алмайды.
struct Excerpt<'a> {
    part: &'a str,
}

// `impl<'a> Excerpt<'a>` repeats the parameter for the methods.
// KZ: `impl<'a> Excerpt<'a>` параметрді әдістер үшін қайталайды.
impl<'a> Excerpt<'a> {
    // The returned &str borrows from `self` (lifetime elision rule), so we do not
    // have to write lifetimes here.
    // KZ: Қайтарылған &str `self`-ден қарыз алады (lifetime elision ережесі), сондықтан мұнда
    //     lifetime жазудың қажеті жоқ.
    fn first_sentence(&self) -> &str {
        self.part.split('.').next().unwrap_or("")
    }
}

fn main() {
    // ---- 1. function with a lifetime parameter -------------------------------
    // KZ: ---- 1. lifetime параметрі бар функция ----
    let a = String::from("Rust");
    let result;
    {
        let b = String::from("lifetimes");
        // `b` dies at the end of this block. If `result` kept a REFERENCE to it,
        // we would get error[E0597] ("borrowed value does not live long enough").
        // Solution: copy the text out with .to_string() so `result` owns it.
        // KZ: `b` осы блоктың соңында жойылады. Егер `result` оған СІЛТЕМЕ сақтаса, error[E0597]
        //     ("borrowed value does not live long enough") шығар еді. Шешімі: `result` иелік
        //     ететіндей мәтінді .to_string() арқылы көшіріп алу.
        result = longest(&a, &b).to_string();
    }
    println!("{}", result);

    // ---- 2. struct that holds a reference -------------------------------------
    // KZ: ---- 2. сілтеме сақтайтын struct ----
    let novel = String::from("Call me Ishmael. Some years ago...");
    let ex = Excerpt { part: &novel }; // `ex` borrows from `novel`
    // KZ: `ex` `novel`-ден қарыз алады
    println!("{}", ex.first_sentence());

    // ---- 3. 'static ---------------------------------------------------------------
    // String literals are stored inside the program itself, so they are valid for
    // the whole run: their lifetime is 'static.
    // KZ: ---- 3. 'static ---- Жол литералдары бағдарламаның өзінде сақталады, сондықтан олар бүкіл
    //     жұмыс бойы жарамды: олардың lifetime-ы 'static.
    let s: &'static str = "string literal";
    println!("{}", s);
}
