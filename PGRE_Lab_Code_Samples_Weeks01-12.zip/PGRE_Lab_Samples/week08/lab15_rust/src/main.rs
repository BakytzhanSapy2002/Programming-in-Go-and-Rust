// =============================================================================
// LAB 15 (Rust) — Apply Rust identifier, type and pattern rules
// Week 8 | Қысқаша: атау стильдері, типтер, shadowing, destructuring, match.
// -----------------------------------------------------------------------------
// KEY IDEAS
//   * Naming: snake_case for variables and functions, CamelCase for types,
//     SCREAMING_SNAKE_CASE for constants. The compiler warns when you break it.
//   * `let` is immutable by default; `let mut` allows changes.
//   * SHADOWING: a new `let` with the same name creates a NEW variable
//     (the type may change). It is NOT the same as `mut`.
//   * Patterns: `match` checks values, ranges, tuples and guards (`if ...`).
//     A match must cover ALL cases (exhaustive) — `_` means "everything else".
//   * Destructuring: take a struct or tuple apart with `let`.
//
// HOW TO RUN:  cargo run
//
// EXPECTED OUTPUT
//   total = 205, average = 68.33
//   value = 84
//   raw identifier
//   Aigerim 87 B
//   (0, 0) -> origin
//   (5, 0) -> positive x axis
//   (-3, 0) -> negative x axis
//   (0, 7) -> y axis
//   (2, 2) -> somewhere else
//   none above 100
//   500 6.4 x | first = 500
// =============================================================================

// A constant: ALWAYS has a type, evaluated at compile time, SCREAMING_SNAKE_CASE.
// KZ: Тұрақты: ӘРҚАШАН типі болады, компиляция кезінде есептеледі, SCREAMING_SNAKE_CASE.
const MAX_SCORE: u32 = 100;

// A struct type: CamelCase name, snake_case fields.
// KZ: Struct типі: CamelCase атау, snake_case өрістер.
struct StudentRecord {
    name: String,
    score: u32,
}

// Turns a score into a grade letter using RANGE patterns.
// `90..=100` is an inclusive range. `_` matches anything left.
// KZ: Баллды ДИАПАЗОН pattern-дері арқылы бағалық әріпке айналдырады. `90..=100` — шегін қоса
//     диапазон. `_` қалған барлығына сәйкес келеді.
fn grade_letter(score: u32) -> char {
    match score {
        90..=100 => 'A',
        75..=89 => 'B',
        50..=74 => 'C',
        _ => 'F', // without this arm the compiler reports "non-exhaustive patterns"
        // KZ: бұл тармақсыз компилятор «non-exhaustive patterns» деп хабарлайды
    }
}

// Matches a TUPLE pattern. `(x, 0) if x > 0` is a pattern with a GUARD:
// the arm is used only when the extra condition is true.
// `&'static str` is a text that lives for the whole program (a string literal).
// KZ: TUPLE pattern-ін салыстырады. `(x, 0) if x > 0` — GUARD-ы бар pattern: тармақ тек қосымша
//     шарт шын болғанда қолданылады. `&'static str` — бағдарламаның бүкіл жұмыс уақытында өмір
//     сүретін мәтін (жол литералы).
fn describe(point: (i32, i32)) -> &'static str {
    match point {
        (0, 0) => "origin",
        (x, 0) if x > 0 => "positive x axis",
        (_, 0) => "negative x axis", // `_` ignores the value
        // KZ: `_` мәнді елемейді
        (0, _) => "y axis",
        _ => "somewhere else",
    }
}

fn main() {
    // ---- arrays and mutability ----------------------------------------------
    // `95u32` gives the first element the type u32; the others follow.
    // KZ: ---- массивтер және өзгермелілік ---- `95u32` бірінші элементке u32 типін береді;
    //     қалғандары соған ілеседі.
    let scores = [95u32, 62, 48]; // array type: [u32; 3] (fixed length)
    // KZ: массив типі: [u32; 3] (ұзындығы тұрақты)
    let mut total: u32 = 0; // `mut` because we change it in the loop
    // KZ: циклде өзгертетін болғандықтан `mut`
    for s in scores.iter() {
        // `iter()` borrows each element, so `s` is a reference (&u32);
        // `u32 += &u32` is allowed by the standard library.
        // KZ: `iter()` әр элементті қарызға алады, сондықтан `s` — сілтеме (&u32); `u32 += &u32`
        //     стандартты кітапханада рұқсат етілген.
        total += s;
    }
    // `as f64` converts between numeric types. Rust never converts silently.
    // KZ: `as f64` сандық типтер арасында түрлендіреді. Rust ешқашан үнсіз түрлендірмейді.
    let average = total as f64 / scores.len() as f64;
    println!("total = {}, average = {:.2}", total, average);

    // ---- SHADOWING -----------------------------------------------------------
    // KZ: ---- SHADOWING ----
    let value = "42"; // &str
    // KZ: &str
    let value: i32 = value.parse().unwrap(); // a NEW variable, now an i32
    // KZ: ЖАҢА айнымалы, енді i32
    let value = value * 2; // another new variable
    // KZ: тағы бір жаңа айнымалы
    println!("value = {}", value);

    // ---- RAW identifier ------------------------------------------------------
    // `type` is a keyword; r# lets us use it as a name (rarely needed).
    // KZ: ---- RAW идентификатор ---- `type` — кілт сөз; r# оны ат ретінде қолдануға мүмкіндік
    //     береді (сирек қажет).
    let r#type = "raw identifier";
    println!("{}", r#type);

    // ---- DESTRUCTURING a struct ---------------------------------------------
    // KZ: ---- struct-ты DESTRUCTURING ----
    let record = StudentRecord { name: String::from("Aigerim"), score: 87 };
    // Take the struct apart into two variables named like the fields.
    // KZ: Struct-ты өріс аттарындай екі айнымалыға бөлшектеңіз.
    let StudentRecord { name, score } = record;
    println!("{} {} {}", name, score, grade_letter(score));

    // ---- match on tuples -----------------------------------------------------
    // An array of tuples can be iterated by value (Rust 2021).
    // KZ: ---- tuple-дарға match ---- Tuple массивін мән бойынша аралауға болады (Rust 2021).
    for p in [(0, 0), (5, 0), (-3, 0), (0, 7), (2, 2)] {
        println!("{:?} -> {}", p, describe(p)); // {:?} = Debug formatting
        // KZ: {:?} = Debug пішімі
    }

    // ---- Option and `if let` ---------------------------------------------------
    // find returns Option<u32>: Some(value) or None (no null in Rust).
    // `.copied()` turns &u32 into u32; `|&s|` destructures the reference.
    // KZ: ---- Option және `if let` ---- find Option<u32> қайтарады: Some(мән) немесе None (Rust-та
    //     null жоқ). `.copied()` &u32-ні u32-ге айналдырады; `|&s|` сілтемені бөлшектейді.
    let above = scores.iter().copied().find(|&s| s > MAX_SCORE);
    if let Some(v) = above {
        println!("above max: {}", v);
    } else {
        println!("none above {}", MAX_SCORE);
    }

    // ---- tuples ---------------------------------------------------------------
    // KZ: ---- tuple-дар ----
    let tuple = (500, 6.4, 'x'); // may mix types
    // KZ: типтерді араластыруға болады
    let (a, b, c) = tuple; // destructuring
    // KZ: destructuring
    println!("{} {} {} | first = {}", a, b, c, tuple.0); // .0 = first element
    // KZ: .0 = бірінші элемент
}
