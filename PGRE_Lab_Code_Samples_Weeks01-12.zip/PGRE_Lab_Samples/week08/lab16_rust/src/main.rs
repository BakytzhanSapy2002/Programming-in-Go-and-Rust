// =============================================================================
// LAB 16 (Rust) — Build a typed Rust command-line program
// Week 8 | Қысқаша: командалық жол аргументтері, Result, өз қате enum-ы, ?.
// -----------------------------------------------------------------------------
// WHAT IT DOES: a calculator for the command line:  <number> <operator> <number>
//
// KEY IDEAS
//   * std::env::args() gives the command-line arguments (the first one is the
//     program name, so we skip it).
//   * Errors are VALUES: functions return Result<T, E>.
//   * An enum describes ALL kinds of errors in one type (CalcError).
//   * The `?` operator: "if this is Err, return it from the current function
//     right now; if it is Ok, take the value out".
//
// HOW TO RUN (note the `--`: it separates cargo's options from the program's)
//   cargo run -- 10 + 5
//   cargo run -- 7 / 0
//   cargo run -- abc + 1
//   cargo run -- 1 2
//
// EXPECTED OUTPUT of `cargo run -- 10 + 5`
//   15
//   --- cargo run -- 7 / 0  (error goes to stderr, exit code 1) ---
//   error: DivisionByZero
//   --- cargo run -- abc + 1 ---
//   error: BadNumber("abc")
// =============================================================================
use std::env;
use std::process;

// All the ways the calculator can fail. Some variants CARRY data.
// KZ: Калькулятор сәтсіз бола алатын барлық жағдайлар. Кейбір нұсқалар деректі ТАСЫЙДЫ.
#[derive(Debug)] // lets us print the value with {:?}
// KZ: мәнді {:?} арқылы шығаруға мүмкіндік береді
enum CalcError {
    WrongArgCount,
    BadNumber(String),
    BadOperator(String),
    DivisionByZero,
}

// Converts text to f64. `parse::<f64>()` returns Result<f64, ParseFloatError>;
// `map_err` replaces the error with OUR error type and keeps the Ok value.
// `|_| ...` is a closure that ignores its argument.
// KZ: Мәтінді f64-ке түрлендіреді. `parse::<f64>()` Result<f64, ParseFloatError> қайтарады;
//     `map_err` қатені БІЗДІҢ қате типімізге ауыстырып, Ok мәнін сақтайды. `|_| ...` — аргументін
//     елемейтін closure.
fn parse_number(text: &str) -> Result<f64, CalcError> {
    text.parse::<f64>()
        .map_err(|_| CalcError::BadNumber(text.to_string()))
}

// Does the arithmetic. `match` on a string slice; `"x" | "*"` = two patterns
// for one arm. The last arm `other` catches every unknown operator.
// KZ: Арифметиканы орындайды. Жол кесіндісіне `match`; `"x" | "*"` = бір тармаққа екі pattern.
//     Соңғы `other` тармағы кез келген белгісіз амалды ұстайды.
fn calculate(a: f64, op: &str, b: f64) -> Result<f64, CalcError> {
    match op {
        "+" => Ok(a + b),
        "-" => Ok(a - b),
        "x" | "*" => Ok(a * b), // `x` is easier to type in PowerShell than `*`
        // KZ: PowerShell-де `x` теру `*`-тен оңай
        "/" => {
            if b == 0.0 {
                Err(CalcError::DivisionByZero)
            } else {
                Ok(a / b)
            }
        }
        other => Err(CalcError::BadOperator(other.to_string())),
    }
}

// Puts everything together. `args: &[String]` BORROWS the arguments (no copy).
// KZ: Бәрін біріктіреді. `args: &[String]` аргументтерді ҚАРЫЗҒА алады (көшіру жоқ).
fn run(args: &[String]) -> Result<f64, CalcError> {
    if args.len() != 3 {
        return Err(CalcError::WrongArgCount);
    }
    // `?` = early return on Err. Without it we would need a `match` each time.
    // KZ: `?` = Err болғанда ерте қайту. Онсыз әр жолы `match` жазуға тура келер еді.
    let a = parse_number(&args[0])?;
    let b = parse_number(&args[2])?;
    calculate(a, &args[1], b)
}

fn main() {
    // skip(1) drops the program name; collect() builds a Vec<String>.
    // KZ: skip(1) бағдарлама атын тастайды; collect() Vec<String> құрады.
    let args: Vec<String> = env::args().skip(1).collect();

    match run(&args) {
        Ok(value) => println!("{}", value),
        Err(e) => {
            // eprintln! writes to STDERR (separate from normal output).
            // KZ: eprintln! STDERR-ге жазады (қалыпты шығарудан бөлек).
            eprintln!("error: {:?}", e);
            // A non-zero exit code tells scripts that the program failed.
            // KZ: Нөлге тең емес шығу коды скрипттерге бағдарламаның сәтсіз аяқталғанын хабарлайды.
            process::exit(1);
        }
    }
}
